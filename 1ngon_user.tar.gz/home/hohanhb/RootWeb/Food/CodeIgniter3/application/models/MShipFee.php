<?php
class MShipFee extends CI_Model{
	private $tb_name="ship_fee";
	
	public function findByIdCustomerTemp($idCustomerTemp){
		$this->db->where('id_customer_temp',$idCustomerTemp);
		return $this->db->get($this->tb_name)->row();
	}
	
	public function insert($arr=array()){
		$this->db->insert($this->tb_name,$arr);
		$insert_id = $this->db->insert_id();

   		return  $insert_id;
	}
	
}