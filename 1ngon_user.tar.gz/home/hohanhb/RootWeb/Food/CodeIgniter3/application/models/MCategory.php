<?php
class MCategory extends CI_Model{
	public function getAll(){
		return $this->db->get('category')->result();
	}
	
	public function find($id){
		$this->db->where('id',$id);
		return $this->db->get('category')->row();
	}
	
	public function insert($arr=array()){
		$this->db->insert('category',$arr);
	}
	
	public function delete($id){
		$this->db->where('id',$id);
		$this->db->delete('category');
	}
	
	public function update($id,$arr=array()){
		$this->db->where('id',$id);
		$this->db->update('category',$arr);
	}
}