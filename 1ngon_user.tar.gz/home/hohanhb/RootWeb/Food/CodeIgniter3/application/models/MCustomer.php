<?php
class MCustomer extends CI_Model{
	private $tb_name="customer";
	public function getAll(){
		return $this->db->get($this->tb_name)->result();
	}
	
	public function find($id){
		$this->db->where('id_customer',$id);
		return $this->db->get($this->tb_name)->row();
	}
	
	public function findByPhone($phone){
		$query = $this->db->query("SELECT * FROM ".$this->tb_name." WHERE phone='".$phone."'");
		return $query->result();
	}
	
	public function insert($arr=array()){
		$this->db->insert($this->tb_name,$arr);
		$insert_id = $this->db->insert_id();

   		return  $insert_id;
	}
	
	public function updateByPhone($phone,$arr=array()){
		$this->db->where('phone',$phone);
		$this->db->update($this->tb_name,$arr);
	}
	
}