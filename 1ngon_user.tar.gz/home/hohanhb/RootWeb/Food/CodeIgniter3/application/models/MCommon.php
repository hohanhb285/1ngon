<?php
class MCommon extends CI_Model{
	
	public function getAllDistrict(){
		$this->db->order_by("id_district", "asc"); 
		return $this->db->get('district')->result();
	}
	
	public function getDistrict($id_district){
		$this->db->where("id_district", $id_district); 
		return $this->db->get('district')->result();
	}
	
		
}