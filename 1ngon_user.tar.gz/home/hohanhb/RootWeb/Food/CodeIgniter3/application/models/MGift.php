<?php
class MGift extends CI_Model{
	private $tb_name="gift";
	public function getAll(){
		return $this->db->get($this->tb_name)->result();
	}
	
	public function find($id){
		$this->db->where('id_gift',$id);
		return $this->db->get($this->tb_name)->row();
	}
	
	public function findByPhone($phone){
		$query = $this->db->query("SELECT g.*,p.product_name FROM ".$this->tb_name." g, customer c, product p WHERE c.id_customer=g.id_customer and c.phone='".$phone."' and g.id_product=p.id_product order by g.id_gift desc");
		return $query->result();
	}
	
	public function insert($arr=array()){
		$this->db->insert($this->tb_name,$arr);
		$insert_id = $this->db->insert_id();

   		return  $insert_id;
	}
	
	
}