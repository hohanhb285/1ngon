<?php
class MNews extends CI_Model{
	private $tb_name="news";
	public function getAllByType($type,$hot=0){
		$this->db->where('status',1);
		$this->db->where('type',$type);
		if($hot)
			$this->db->where('hot',$hot);
		$this->db->order_by("id_news", "desc"); 
		return $this->db->get($this->tb_name)->result();
	}
	
	public function find($id){
		$this->db->where('id_news',$id);
		return $this->db->get($this->tb_name)->row();
	}
	
	public function insert($arr=array()){
		$this->db->insert($this->tb_name,$arr);
		$insert_id = $this->db->insert_id();

   		return  $insert_id;
	}
	
}