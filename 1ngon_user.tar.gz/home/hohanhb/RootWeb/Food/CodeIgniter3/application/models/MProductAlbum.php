<?php
class MProductAlbum extends CI_Model{
	private $tb_name="product_album";
	public function getAll($type){
		$this->db->where('type',$type);
		$this->db->where('status',1);
		return $this->db->get($this->tb_name)->result();
	}
	
}