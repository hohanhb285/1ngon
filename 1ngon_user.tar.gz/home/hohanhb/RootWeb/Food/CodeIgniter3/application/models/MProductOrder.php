<?php
class MProductOrder extends CI_Model{
	private $tb_name="product_order";
	public function getProductOrdered($id_customer_temp){
		$query = $this->db->query("SELECT p.product_name,p.product_name_tv,p.price,p.description,p.product_image,o.*,d.product_name_detail,d.size as detail_size,d.note as detail_note FROM ".$this->tb_name." o,product p,product_detail d WHERE o.id_product=p.id_product and o.id_product_detail=d.id_product_detail and o.id_customer_temp='".$id_customer_temp."' ORDER BY o.id_product_order ASC");
		
		return $query->result();
	}

	public function getPriceTotalProductOrdered($id_customer_temp){
		$query = $this->db->query("SELECT sum(quantity*price) as money_total FROM ".$this->tb_name." WHERE id_customer_temp='".$id_customer_temp."'");
		//127.0.0.11461124174
		return $query->result();
	}
	
	public function insert($arr=array()){
		$this->db->insert($this->tb_name,$arr);
	}
	
	public function update($id_product_order,$arr=array()){
		$this->db->where('id_product_order',$id_product_order);
		$this->db->update($this->tb_name,$arr);
	}
	
	public function update2($id_customer_temp,$id_customer,$id_product,$id_product_detail,$quantity,$taste){
		if($id_product_detail){
			$query = $this->db->query("update ".$this->tb_name." set quantity='".$quantity."',taste='".$taste."' WHERE id_customer_temp='".$id_customer_temp."' and id_customer='".$id_customer."' and id_product='".$id_product."' and id_product_detail='".$id_product_detail."'");
			echo $query;
			return $query->result();
		}else
		return array();
	}
	function updateRowWhere($where = array(), $data = array()) {
	    $this->db->where($where);
	    $this->db->update($this->tb_name, $data);
	}
	public function delete($id){
		$this->db->where('id_product_order',$id);
		$this->db->delete($this->tb_name);
	}
	
	public function updateByIdCustomerTemp($id_customer_temp,$arr=array()){
		$this->db->where('id_customer_temp',$id_customer_temp);
		$this->db->update($this->tb_name,$arr);
	}
	
	public function confirmCard($id_product_order,$arr=array()){
		$this->db->where('id_product_order',$id_product_order);
		$this->db->update($this->tb_name,$arr);
	}
	
	public function findByParentPhone($parent_phone){
		if($parent_phone){
			$query = $this->db->query("SELECT o.id_customer,c.phone,c.fullname,c.address, sum(o.quantity*o.price) as money_total,sum(o.quantity) as quantity_total FROM ".$this->tb_name." o, customer c, product p WHERE o.id_product=p.id_product and c.id_customer=o.id_customer and c.parent_phone='".$parent_phone."' and p.id_product_type in(1,2,3,4) group by o.id_customer,c.phone,c.fullname,c.address order by o.id_customer desc");
			return $query->result();
		}else
		return array();
	}
	
	public function orderListByParentPhone($parent_phone,$id_customer=''){
		if($parent_phone){
			if($id_customer>0)
				$query = $this->db->query("SELECT o.*,c.phone,c.fullname,c.address,p.product_name FROM ".$this->tb_name." o, customer c, product p WHERE c.id_customer=o.id_customer and c.parent_phone='".$parent_phone."' and o.id_customer='".$id_customer."' and p.id_product=o.id_product and p.id_product_type in(1,2,3,4) order by c.id_customer desc, o.id_product_order desc");
			else	
				$query = $this->db->query("SELECT o.*,c.phone,c.fullname,c.address,p.product_name FROM ".$this->tb_name." o, customer c, product p WHERE c.id_customer=o.id_customer and c.parent_phone='".$parent_phone."' and p.id_product=o.id_product and p.id_product_type in(1,2,3,4) order by c.id_customer desc, o.id_product_order desc");
			return $query->result();
		}else
		return array();
	}
	
	public function orderListByParentPhoneToCalcGift($parent_phone){
		if($parent_phone){
			$query = $this->db->query("SELECT o.*,c.phone,c.fullname,c.address,p.product_name FROM ".$this->tb_name." o, customer c, product p WHERE c.id_customer=o.id_customer and c.parent_phone='".$parent_phone."' and p.id_product=o.id_product and p.id_product_type in(1,2,3,4) order by o.id_product_order asc");
			return $query->result();
		}else
		return array();	
	}
	
}