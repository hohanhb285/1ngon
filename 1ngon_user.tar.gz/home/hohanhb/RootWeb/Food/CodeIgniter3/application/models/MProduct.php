<?php
class MProduct extends CI_Model{
	private $tb_name="product";
	public function getAllActive($id_product_type=''){
		if($id_product_type)
			$this->db->where('id_product_type',$id_product_type);
		$this->db->where('status',1);
		$this->db->order_by("position", "asc"); 	
		return $this->db->get($this->tb_name)->result();
	}
	
	public function getAll($id_product_type=''){
		if($id_product_type)
			$this->db->where('id_product_type',$id_product_type);
			$this->db->order_by("position", "asc");
		return $this->db->get($this->tb_name)->result();
	}
	
	public function getAllByType($type=''){
		if($type)
			$query = $this->db->query("SELECT p.* FROM ".$this->tb_name." p, product_type t WHERE p.id_product_type=t.id_product_type and t.type<>".$type);
		
		return $query->result();
	}
	
	public function find($id){
		$this->db->where('id_product',$id);
		return $this->db->get($this->tb_name)->row();
	}
	
	public function findByProductNameTV($product_name_tv){
		$this->db->where('product_name_tv',$product_name_tv);
		return $this->db->get($this->tb_name)->row();
	}
	
	public function findOtherProduct($id){
		$query = $this->db->query("SELECT * FROM ".$this->tb_name." WHERE status=1 and id_product<>".$id);
		
		return $query->result();
	}
	
	public function getProductLiked(){
		$query = $this->db->query("SELECT count(*) as c,o.id_product,p.product_name,p.product_name_tv,p.price,p.product_image FROM product p,product_order o WHERE p.status=1 and o.id_product=p.id_product GROUP BY o.id_product,p.product_name,p.product_name_tv,p.product_thumb ORDER BY c DESC");
		
		return $query->result();
	}
	
	public function writeLog($arr=array()){
		$this->db->insert("log",$arr);
	}
	
}