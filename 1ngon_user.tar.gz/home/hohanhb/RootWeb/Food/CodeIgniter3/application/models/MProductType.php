<?php
class MProductType extends CI_Model{
	private $tb_name="product_type";
	public function getAll($type){
		$this->db->where('type',$type);
		return $this->db->get($this->tb_name)->result();
	}
	
}