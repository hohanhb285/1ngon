<?php
class MProductDetail extends CI_Model{
	private $tb_name="product_detail";
	public function getAllActive($id_product=''){
		if($id_product)
			$this->db->where('id_product',$id_product);
		$this->db->where('status',1);
		$this->db->order_by("position", "asc"); 	
		return $this->db->get($this->tb_name)->result();
	}
	
	public function getAllActiveStandard($id_product=''){
		if($id_product)
			$this->db->where('id_product',$id_product);
		$this->db->where('status',1);
		$this->db->where('standard',1);		
		return $this->db->get($this->tb_name)->result();
	}
	
	public function getAll($id_product=''){
		if($id_product)
			$this->db->where('id_product',$id_product);
			$this->db->order_by("position", "asc");
		return $this->db->get($this->tb_name)->result();
	}	
		
}