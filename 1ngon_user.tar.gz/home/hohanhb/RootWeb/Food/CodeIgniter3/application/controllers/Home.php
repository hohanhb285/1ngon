<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Home extends CI_Controller{
	function __construct(){      
	        parent::__construct();
	        
	        /*$CI =& get_instance();
			$CI->load->library('CI_My_Common');
			$CI->CI_My_Common->loadHeader();
			*/
	        $data['product_type_1']=$this->MProductType->getAll(1);//Món chính
	        $data['product_type_2']=$this->MProductType->getAll(2);//Món phụ
	        $data['product_type_3']=$this->MProductType->getAll(3);//Nước uống
	        $arr_product_album_1=$this->MProductAlbum->getAll(1);//Slider show
	        $this->session->set_userdata('product_album_1',$arr_product_album_1);
	        //Get id_product_detail list
	        if(!$this->session->userdata('product_detail_standard')){
		        $arr_product_detail_standard=$this->MProductDetail->getAllActiveStandard();
		        foreach($arr_product_detail_standard as $product_detail_standard_row){
		        	$product_detail_standard[$product_detail_standard_row->id_product]=$product_detail_standard_row->id_product_detail;
		        }
		        $this->session->set_userdata('product_detail_standard',$product_detail_standard);
		        //var_dump($this->session->userdata('product_detail_standard'));
	        }
			$this->load->view('VHeader',$data, TRUE);
	
	}
	
	public function index($id_product_type=''){
		if($id_product_type)
			$data['product']=$this->MProduct->getAllActive($id_product_type);
		else
			$data['product']=$this->MProduct->getAllActive();
			
		$data['content']=$this->load->view('VHome',$data, TRUE);
		//$this->session->sess_destroy();	
		$this->load->view('VLayout',$data);
	}
	
	public function all($id_product_type=''){
		if($id_product_type)
			$data['product']=$this->MProduct->getAll($id_product_type);
		else
			$data['product']=$this->MProduct->getAll();
			
		$data['content']=$this->load->view('VHome',$data, TRUE);
		//$this->session->sess_destroy();	
		$this->load->view('VLayout',$data);
	}
	
}