<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class News extends CI_Controller{
	
	function __construct(){      
	        parent::__construct();
	        $data['product_type_1']=$this->MProductType->getAll(1);//Món chính
	        $data['product_type_2']=$this->MProductType->getAll(2);//Món phụ
	        $data['product_type_3']=$this->MProductType->getAll(3);//Nước uống
			$this->load->view('VHeader',$data, TRUE);
	
	}
	
	//about
	public function about_us(){
		$type=1;
		$this->session->set_userdata('news_type',$type);
		$data['news']=$this->MNews->getAllByType($type,1);
		$data['content']=$this->load->view('VNews',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);
		
	}
	
	//invite program
	public function invite(){
		$type=2;
		$this->session->set_userdata('news_type',$type);
		$data['news']=$this->MNews->getAllByType($type,1);
		$data['content']=$this->load->view('VNews',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);
	
	}
	
	//ship
	public function ship(){
		$type=3;
		$this->session->set_userdata('news_type',$type);
		$data['news']=$this->MNews->getAllByType($type,1);
		$data['content']=$this->load->view('VNews',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);
	
	}
	
	//promotion
	public function promotion(){
		$type=4;
		$this->session->set_userdata('news_type',$type);
		$data['news']=$this->MNews->getAllByType($type,1);
		$data['content']=$this->load->view('VNews',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);
	
	}
}