<?php
class Category extends CI_Controller{
	
	public function index(){
		$data['category']=$this->MCategory->getAll();
		$this->load->view('VCategory',$data);
	}
	
	public function delete($id){
		$this->MCategory->delete($id);
		redirect('category/index/');
	}
	
	public function add(){
		$this->load->view('VCategoryAdd');
		
	}
	
	public function update($id){
		$data['category']=$this->MCategory->find($id);
		$this->load->view('VCategoryUpdate',$data);
		
	}
	
	public function submit_add(){
		$this->form_validation->set_error_delimiters('<div class="error">', '</div>');
		$this->form_validation->set_rules('txt_category_name', 'Category name', 'trim|required|min_length[5]|max_length[12]');
		$this->form_validation->set_rules('txt_email', 'Email', 'required|valid_email');
		$this->form_validation->set_rules('txt_phone', 'Phone', 'required|numeric');
		
		if ($this->form_validation->run() == TRUE){
			$data=array('name'=>$this->input->post('txt_category_name'));
			$this->MCategory->insert($data);
			redirect('category/index/');
		}else
			$this->load->view('VCategoryAdd');
	}
	
	public function submit_update(){
		
		$data=array('name'=>$this->input->post('txt_category_name'));
		$this->MCategory->update($this->input->post('txt_category_id'),$data);
		redirect('category/index/');
	}
		
	

}