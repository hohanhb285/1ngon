<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Product extends CI_Controller{
	
	function __construct(){      
	        parent::__construct();
	        //$this->session->sess_destroy();
	        $data['product_type_1']=$this->MProductType->getAll(1);//Món chính
	        $data['product_type_2']=$this->MProductType->getAll(2);//Món phụ
	        $data['product_type_3']=$this->MProductType->getAll(3);//Nước uống
	        //Slide
	        $arr_product_album_1=$this->MProductAlbum->getAll(1);//Slider show
	        $this->session->set_userdata('product_album_1',$arr_product_album_1);
			//Get id_product_detail list
	        if(!$this->session->userdata('product_detail_standard')){
		        $arr_product_detail_standard=$this->MProductDetail->getAllActiveStandard();
		        foreach($arr_product_detail_standard as $product_detail_standard_row){
		        	$product_detail_standard[$product_detail_standard_row->id_product]=$product_detail_standard_row->id_product_detail;
		        }
		        $this->session->set_userdata('product_detail_standard',$product_detail_standard);
		        //var_dump($this->session->userdata('product_detail_standard'));
	        }	
	        $this->load->view('VHeader',$data, TRUE);
	
	}
	
	public function index($id_product_type=''){
		//if($id_product_type)
			//$data['product']=$this->MProduct->getAllActive($id_product_type);
		//else
			$data['product']=$this->MProduct->getAllActive();

		$data['content']=$this->load->view('VHome',$data, TRUE);
		//$this->session->sess_destroy();	
		$this->load->view('VLayout',$data);
	}
	
	public function fb($id_product_type=''){
		if($id_product_type)
			$data['product']=$this->MProduct->getAllActive($id_product_type);
		else
			$data['product']=$this->MProduct->getAllActive();

		$data['content']=$this->load->view('VHomeFB',$data, TRUE);
		//$this->session->sess_destroy();	
		$this->load->view('VLayout',$data);
	}
	
	public function all($id_product_type=''){
		if($id_product_type)
			$data['product']=$this->MProduct->getAll($id_product_type);
		else
			$data['product']=$this->MProduct->getAll();
			
		$data['content']=$this->load->view('VHome',$data, TRUE);
		//$this->session->sess_destroy();	
		$this->load->view('VLayout',$data);
	}
	
	public function type($type=''){
		if($type)
			$data['product']=$this->MProduct->getAll($type);
			
		$data['content']=$this->load->view('VHome',$data, TRUE);
		//$this->session->sess_destroy();	
		$this->load->view('VLayout',$data);
	}
	
	public function detail($product_name_tv){
		if(is_numeric($product_name_tv)){
			$data['product']=$this->MProduct->find($product_name_tv);
			$id=$product_name_tv;
		}else{
			$data['product']=$this->MProduct->findByProductNameTV($product_name_tv);
			$id=$data['product']->id_product;
		}
		$data['other_product']=$this->MProduct->findOtherProduct($id);
		$data['liked_product']=$this->MProduct->getProductLiked();
		$data['product_detail']=$this->MProductDetail->getAllActive($id);
		
		$data['content']=$this->load->view('VProductDetail',$data, TRUE);
		
		$this->load->view('VLayout',$data);
	}
	
	public function order($id_product,$id_product_detail,$price,$quantity=1,$taste=1,$call_from=1){
		if(is_numeric($quantity))
			$quantity=intval($quantity);
		else
			$quantity=1;	
		//$this->session->unset_userdata('product_ordered');
		//die("eee");
		if(!$this->session->userdata('customer_info')){
			$this->session->set_userdata('customer_add_card',array(0=>$id_product,1=>$id_product_detail,2=>$price,3=>$quantity,4=>$taste,5=>$call_from));
			//var_dump($this->session->userdata('customer_add_card'));
			echo -1;
			exit();
		}
		//Create temp id_customer
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		if(!$id_customer_temp){
			$id_customer_rand=substr(microtime(),-18);//$this->getClientIP().time();
			$this->session->set_userdata('id_customer_temp',$id_customer_rand);
		}
		$id_customer_temp=$this->session->userdata('id_customer_temp');
				
		//Create list product ordered
		$arr_product_ordered=$this->session->userdata('product_ordered');
		$arr_price_ordered=$this->session->userdata('price_ordered');
		$arr_quantity_ordered=$this->session->userdata('quantity_ordered');
		$flag_insert=1;
		if(is_array($arr_product_ordered)){
			if(!isset($arr_product_ordered[$id_product][$id_product_detail])){
				$arr_product_ordered[$id_product][$id_product_detail]=$id_product."_".$id_product_detail;
				$arr_price_ordered[$id_product][$id_product_detail]=$price;
				$arr_quantity_ordered[$id_product][$id_product_detail]=$quantity;
			}else{
				$flag_insert=0;
				$arr_price_ordered[$id_product][$id_product_detail]=$price;
				$arr_quantity_ordered[$id_product][$id_product_detail]=$quantity;
			}
		}else{
			$arr_product_ordered[$id_product][$id_product_detail]=$id_product."_".$id_product_detail;
			$arr_price_ordered[$id_product][$id_product_detail]=$price;
			$arr_quantity_ordered[$id_product][$id_product_detail]=$quantity;
		}
		$this->session->set_userdata('product_ordered',$arr_product_ordered);
		$this->session->set_userdata('price_ordered',$arr_price_ordered);
		$this->session->set_userdata('quantity_ordered',$arr_quantity_ordered);
		
		//Save data
		if($flag_insert==1){
			$created_datetime=date('Y-m-d H:i:s',time());
			$arr_customer_info1=$this->session->userdata('customer_info');			
			$data_insert=array('id_product'=>$id_product,'id_product_detail'=>$id_product_detail,'quantity'=>$quantity,'taste'=>$taste,'id_customer'=>$arr_customer_info1['id_customer'],'id_customer_temp'=>$id_customer_temp,'price'=>$price,'created_by'=>'customer','created_datetime'=>$created_datetime);
			$this->MProductOrder->insert($data_insert);
		
			//$this->session->unset_userdata('product_ordered');
			//echo "<pre>";
			//	print_r($this->session->userdata('product_ordered'));
			//echo "</pre>";
		}else{
			$arr_customer_info1=$this->session->userdata('customer_info');
			//$this->MProductOrder->update2($id_customer_temp,$arr_customer_info1['id_customer'],$id_product,$id_product_detail,$quantity,$taste);
			$data_update=array('quantity'=>$quantity,'taste'=>$taste);
			$data_where=array('id_customer_temp'=>$id_customer_temp,'id_customer'=>$arr_customer_info1['id_customer'],'id_product'=>$id_product,'id_product_detail'=>$id_product_detail);
			
			$this->MProductOrder->updateRowWhere($data_where,$data_update);		
		}
		
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		$price_total=$this->MProductOrder->getPriceTotalProductOrdered($id_customer_temp);
		$price_total_tmp=number_format($price_total[0]->money_total);
		echo $price_total_tmp;
		$this->session->set_userdata('price_total_show',$price_total_tmp);
	}
	
	function getClientIP() {
	
	    if (isset($_SERVER)) {
	
	        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"]))
	            return $_SERVER["HTTP_X_FORWARDED_FOR"];
	
	        if (isset($_SERVER["HTTP_CLIENT_IP"]))
	            return $_SERVER["HTTP_CLIENT_IP"];
	
	        return $_SERVER["REMOTE_ADDR"];
	    }
	
	    if (getenv('HTTP_X_FORWARDED_FOR'))
	        return getenv('HTTP_X_FORWARDED_FOR');
	
	    if (getenv('HTTP_CLIENT_IP'))
	        return getenv('HTTP_CLIENT_IP');
	
	    return getenv('REMOTE_ADDR');
	}
	
	public function checkout(){
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		$data['product_ordered']=$this->MProductOrder->getProductOrdered($id_customer_temp);
		$data['content']=$this->load->view('VCheckOut',$data, TRUE);
		
		$this->load->view('VLayout',$data);
	}
		
	public function editCard($id_product_order,$id_product,$id_product_detail,$price,$quantity){
		$data_update=array('quantity'=>$quantity);
		$this->MProductOrder->update($id_product_order,$data_update);
		
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		$price_total=$this->MProductOrder->getPriceTotalProductOrdered($id_customer_temp);
		$price_total_tmp=number_format($price_total[0]->money_total);
		echo $price_total_tmp;
		$this->session->set_userdata('price_total_show',$price_total_tmp);
		
		//Update array session
		$arr_product_ordered=$this->session->userdata('product_ordered');
		$arr_price_ordered=$this->session->userdata('price_ordered');
		$arr_quantity_ordered=$this->session->userdata('quantity_ordered');
		if(is_array($arr_product_ordered)){
			$arr_product_ordered[$id_product][$id_product_detail]=$id_product."_".$id_product_detail;;
			$arr_price_ordered[$id_product][$id_product_detail]=$price;
			$arr_quantity_ordered[$id_product][$id_product_detail]=$quantity;
			if(empty($arr_product_ordered[$id_product])){
				unset($arr_product_ordered[$id_product]);
				unset($arr_price_ordered[$id_product]);
				unset($arr_quantity_ordered[$id_product]);
			}
			$this->session->set_userdata('product_ordered',$arr_product_ordered);
			$this->session->set_userdata('price_ordered',$arr_price_ordered);
			$this->session->set_userdata('quantity_ordered',$arr_quantity_ordered);
		}
	}
	
	public function deleteCard($id_product_order,$id_product,$id_product_detail){
		//Delete id_product_order
		$this->MProductOrder->delete($id_product_order);
		
		//Recalc money total
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		$price_total=$this->MProductOrder->getPriceTotalProductOrdered($id_customer_temp);
		$price_total_tmp=number_format($price_total[0]->money_total);
		if($price_total_tmp==0) $price_total_tmp="";
		echo $price_total_tmp;
		$this->session->set_userdata('price_total_show',$price_total_tmp);
		
		//Update array session
		$arr_product_ordered=$this->session->userdata('product_ordered');
		$arr_price_ordered=$this->session->userdata('price_ordered');
		$arr_quantity_ordered=$this->session->userdata('quantity_ordered');
		if(is_array($arr_product_ordered)){
			unset($arr_product_ordered[$id_product][$id_product_detail]);
			unset($arr_price_ordered[$id_product][$id_product_detail]);
			unset($arr_quantity_ordered[$id_product][$id_product_detail]);
			if(empty($arr_product_ordered[$id_product])){
				unset($arr_product_ordered[$id_product]);
				unset($arr_price_ordered[$id_product]);
				unset($arr_quantity_ordered[$id_product]);
			}
			$this->session->set_userdata('product_ordered',$arr_product_ordered);
			$this->session->set_userdata('price_ordered',$arr_price_ordered);
			$this->session->set_userdata('quantity_ordered',$arr_quantity_ordered);
		}
			
	}
	
	public function confirmCard(){
		
		if($this->input->post('phone')){
			$phone=$_POST['phone'];
			$address=$_POST['address'];
			$note=$_POST['note'];
			$district=$_POST['district'];
		
			$data_customer=$this->MCustomer->findByPhone($phone);
			$id_customer_temp=$this->session->userdata('id_customer_temp');
			$created_datetime=date('Y-m-d H:i:s',time());
			if(!empty($data_customer)){
				$id_customer=$data_customer[0]->id_customer;
				$data_update=array('id_customer'=>$id_customer);
				$this->MProductOrder->updateByIdCustomerTemp($id_customer_temp,$data_update);
				//$this->session->sess_destroy();
				$this->session->set_userdata('customer_info',array('id_customer'=>$id_customer,'phone'=>$phone,'address'=>$address,'note'=>$note));	
			}else{
				$data_insert=array('phone'=>$phone,'address'=>$address,'created_by'=>'customer','created_datetime'=>$created_datetime);
				$new_id_customer=$this->MCustomer->insert($data_insert);
				
				$data_update=array('id_customer'=>$new_id_customer);			
				$this->MProductOrder->updateByIdCustomerTemp($id_customer_temp,$data_update);
				$this->session->set_userdata('customer_info',array('id_customer'=>$new_id_customer,'phone'=>$phone,'address'=>$address,'note'=>$note));
			}
			$arr_district_info=$this->MCommon->getDistrict($district);
			
			//if($arr_district_info[0]->ship_fee){
				$data_fee_insert=array('id_customer_temp'=>$id_customer_temp,'ship_fee'=>$arr_district_info[0]->ship_fee,'id_district'=>$district,'address'=>$address,'note'=>$note,'created_datetime'=>$created_datetime);
				$this->MShipFee->insert($data_fee_insert);
			//}
			
			$this->session->set_userdata('ship_fee_info',array('district'=>$district,'district_name'=>$arr_district_info[0]->district_name,'ship_fee'=>$arr_district_info[0]->ship_fee));
			header('Location: '.SITE_URL.'product/orderinfo/');
		}
		
		$id_customer_temp=$this->session->userdata('id_customer_temp');			
		$data['product_ordered']=$this->MProductOrder->getProductOrdered($id_customer_temp);
		
		$data['district']=$this->MCommon->getAllDistrict();
		$data['content']=$this->load->view('VConfirm',$data, TRUE);
		$this->load->view('VLayout',$data);
		
	}
	
public function orderInfo(){
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		$data['product_ordered']=$this->MProductOrder->getProductOrdered($id_customer_temp);
		
		$data['district']=$this->MCommon->getAllDistrict();
		$data['content']=$this->load->view('VOrderInfo',$data, TRUE);
		$this->load->view('VLayout',$data);
		
	}
	
public function writeLog($title,$type,$status){
		$created_datetime=date('Y-m-d H:i:s',time());
		$data_insert=array('title'=>$title,'type'=>$type,'status'=>$status,'created_datetime'=>$created_datetime);
		$this->MProduct->writeLog($data_insert);
	}
}