<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Friends extends CI_Controller{
	
	function __construct(){      
	        parent::__construct();
	        $data['product_type_1']=$this->MProductType->getAll(1);//Món chính
	        $data['product_type_2']=$this->MProductType->getAll(2);//Món phụ
	        $data['product_type_3']=$this->MProductType->getAll(3);//Món phụ
			$this->load->view('VHeader',$data, TRUE);
	
	}
	
	public function view(){
		$arr_customer_info=$this->session->userdata('customer_info');
		if(!$arr_customer_info){
			header('Location: '.SITE_URL.'login/index/ordercheck/');
			exit();
		}
		$data['friends']=$this->MProductOrder->findByParentPhone($arr_customer_info['phone']);
		$data['gift']=$this->MGift->findByPhone($arr_customer_info['phone']);
		$data['content']=$this->load->view('VFriends',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);
		
	}
	
	public function order($id_customer=''){
		$arr_customer_info=$this->session->userdata('customer_info');
		$data['friends_order']=$this->MProductOrder->orderListByParentPhone($arr_customer_info['phone'],$id_customer);
		$data['content']=$this->load->view('VFriendsDetail',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);		
	}
	
	public function gift(){
		$arr_customer_info=$this->session->userdata('customer_info');
		$data['friends_order']=$this->MProductOrder->orderListByParentPhoneToCalcGift($arr_customer_info['phone']);
		$data['gift']=$this->MGift->findByPhone($arr_customer_info['phone']);
		$data['content']=$this->load->view('VFriendsGift',$data, TRUE);
		//var_dump($data);
		$this->load->view('VLayout',$data);		
	}
}