<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Hello extends CI_Controller {
	public function index(){
		echo "Hello!";
	}
	
	public function hienthi($hienthi){
		echo $hienthi;
	}
	
	public function cong($a,$b){
		echo $a+$b;
	}
	
	public function callview(){
		
		$data['a']="gia tri a";
		$data['b']="gia tri b";
		$this->load->view('hello',$data);
	}
	
}