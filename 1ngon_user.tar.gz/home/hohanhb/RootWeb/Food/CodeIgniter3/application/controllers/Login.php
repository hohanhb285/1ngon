<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Login extends CI_Controller{
	
	function __construct(){      
	        parent::__construct();
	        $data['product_type_1']=$this->MProductType->getAll(1);//Món chính
	        $data['product_type_2']=$this->MProductType->getAll(2);//Món phụ
	        $data['product_type_3']=$this->MProductType->getAll(3);//Nước uống
			$this->load->view('VHeader',$data, TRUE);
	
	}
	
	public function login2($phone=''){
		if($phone<>''){				
			$data['customer']=$this->MCustomer->findByPhone($phone);
			if($data['customer']){
				$this->session->set_userdata('customer_info',array('id_customer'=>$data['customer'][0]->id_customer,'phone'=>$phone,'address'=>$data['customer'][0]->address,'note'=>''));
				echo 1;			
			}else{
				$created_datetime=date('Y-m-d H:i:s',time());
				$data_insert=array('phone'=>$phone,'address'=>'','created_by'=>'customer','created_datetime'=>$created_datetime);
				$new_id_customer=$this->MCustomer->insert($data_insert);				
				$this->session->set_userdata('customer_info',array('id_customer'=>$new_id_customer,'phone'=>$phone,'address'=>'','note'=>''));
				echo 1;
			}					
		}else{
			$data['content']=$this->load->view('VLogin2','', TRUE);		
			$this->load->view('VLayout',$data);
		}		
	}
	
	public function index(){
		if($this->session->userdata('customer_info')){
			header('Location: '.SITE_URL.'product');
			exit();
		}
		$arr_Server=$_SERVER;
		if(!$this->input->post('btn_Submit')){
			//if($_SERVER['HTTP_REFERER']<>"http://localhost/Food/CodeIgniter2/index.php/login/" && $_SERVER['HTTP_REFERER']<>"http://1ngon.vn/login/" && $_SERVER['HTTP_REFERER']<>"https://1ngon.vn/login/" && $_SERVER['HTTP_REFERER']<>"http://1ngon.com/login/" && $_SERVER['HTTP_REFERER']<>"https://1ngon.com/login/"){
				if(array_key_exists('HTTP_REFERER',$arr_Server))
					$this->session->set_userdata('HTTP_REFERER',$_SERVER['HTTP_REFERER']);					
				else
					$this->session->set_userdata('HTTP_REFERER','');

				if($this->uri->segment(3)=='ordercheck')
					$this->session->set_userdata('HTTP_REFERER',SITE_URL.'friends/view/');
			//}	
		}
		if($this->input->post('btn_Submit')){
			if($_POST['phone']){					
				$data['customer']=$this->MCustomer->findByPhone($_POST['phone']);
				if($data['customer']){
					$data['result']=1;
					$this->session->set_userdata('customer_info',array('id_customer'=>$data['customer'][0]->id_customer,'phone'=>$_POST['phone'],'address'=>$data['customer'][0]->address,'note'=>'','district'=>''));
					if($this->session->userdata('HTTP_REFERER')){
						header('Location: '.$this->session->userdata('HTTP_REFERER'));
					}else
						header('Location: '.SITE_URL.'product');		
				}else
					$data['result']=2;					
			}else{
				$data['result']=0;
			}
				
		}else
		$data['result']=-1;		
		$data['content']=$this->load->view('VLogin',$data, TRUE);		
		$this->load->view('VLayout',$data);		
	}
	
	public function logout(){
		$this->session->sess_destroy();	
		header('Location: '.SITE_URL.'product/');
	}
	
}