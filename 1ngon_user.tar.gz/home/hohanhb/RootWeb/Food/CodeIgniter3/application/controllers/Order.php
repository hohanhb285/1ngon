<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Order extends CI_Controller{
	
	public function add($id_product){
		//$this->session->unset_userdata('product_ordered');
		//$this->session->unset_userdata('id_customer_temp');
		//die();
		
		//Create temp id_customer
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		if(!$id_customer_temp){
			$id_customer_rand=substr(microtime(),-18);//$this->getClientIP().time();
			$this->session->set_userdata('id_customer_temp',$id_customer_rand);
		}
		$id_customer_temp=$this->session->userdata('id_customer_temp');
		//$this->session->unset_userdata('product_ordered');
		//$this->session->unset_userdata('id_customer_temp');
		//return;
		
		//Create list product ordered
		$arr_product_ordered=$this->session->userdata('product_ordered');
		if(is_array($arr_product_ordered)){
			if(!array_key_exists($id_product,$arr_product_ordered))
				$arr_product_ordered[$id_product]=$id_product;
		}else
			$arr_product_ordered[$id_product]=$id_product;
		$this->session->set_userdata('product_ordered',$arr_product_ordered);
		
		//Save data
		$created_datetime=date('Y-m-d H:i:s',time());
		$data_insert=array('id_product'=>$id_product,'id_customer_temp'=>$id_customer_temp,'created_by'=>'customer','created_datetime'=>$created_datetime);
		$this->MProductOrder->insert($data_insert);
		
		//$this->session->unset_userdata('product_ordered');
		//echo "<pre>";
		//	print_r($this->session->userdata('product_ordered'));
		//echo "</pre>";
		
	}
	
	
function getClientIP() {

    if (isset($_SERVER)) {

        if (isset($_SERVER["HTTP_X_FORWARDED_FOR"]))
            return $_SERVER["HTTP_X_FORWARDED_FOR"];

        if (isset($_SERVER["HTTP_CLIENT_IP"]))
            return $_SERVER["HTTP_CLIENT_IP"];

        return $_SERVER["REMOTE_ADDR"];
    }

    if (getenv('HTTP_X_FORWARDED_FOR'))
        return getenv('HTTP_X_FORWARDED_FOR');

    if (getenv('HTTP_CLIENT_IP'))
        return getenv('HTTP_CLIENT_IP');

    return getenv('REMOTE_ADDR');
}	
	
		
	

}