<div class="boxfbchat"  style="position: fixed;bottom: 0;right: 0;z-index: 500;">
		<div class="box_hotro">
			<span class="text">Liên hệ 1ngon</span>
		</div>
		<label for="navbar-toggle" id="lb_close" class="label_close">Chat</label>
		<iframe src="https://www.facebook.com/plugins/page.php?href=https://facebook.com/1ngon&tabs=messages&width=250&height=250&small_header=true&adapt_container_width=false&hide_cover=true&show_facepile=false&appId=252680568443717" width="250" height="250" style="border:none;overflow:hidden" scrolling="no" frameborder="0" allowTransparency="true"></iframe>
</div>