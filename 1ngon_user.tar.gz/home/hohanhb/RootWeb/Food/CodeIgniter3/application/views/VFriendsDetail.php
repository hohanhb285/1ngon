<div class="container">
	<div class="check-out">
		<div id="id_message" style="text-align:right;padding-right:5%"><a onclick="javascript:history.back();"><< Back </a></div>   
		<table id="CheckOutTable" class="csstable">
		  <tr>
		  	<th class="cssth"></th>		  	
			<th class="cssth">Điện thoại</th>		
			<th class="cssth" style="width:30%">Sản phẩm</th>
			<th class="cssth">Giá</th>
			<th class="cssth">SL</th>	
			<th class="cssth">Thời gian</th>			
		  </tr>
		  <?php 
		  	$num=0;
		  	$quantity_total=0;
		  	$pre_phone="";
		  	foreach($friends_order as $list){ 
			$num++;
			$quantity_total+=$list->quantity;			
			?>
		  <tr>
			<td class="csstd"><?php echo $num;?></td>			
			<td class="csstd"><?php if($list->phone<>$pre_phone) echo $list->phone; else echo "//";?></td>		
			<td class="csstd"><?php echo $list->product_name;?></td>
			<td class="csstd"><?php echo number_format($list->price);?></td>
			<td class="csstd"><?php echo number_format($list->quantity);?></td>
			<td class="csstd"><?php echo $list->created_datetime;?></td>
		  </tr>		  
		  <?php $pre_phone=$list->phone;}?>
		  <tr>
			<td class="csstd" colspan="4" style="text-align:right"><strong>Tổng SL mua </strong></td>			
			<td class="csstd" colspan="2"><?php echo $quantity_total;?></td>
		  </tr>
		</table>
	
	<div class="clearfix"> </div>
	
	</div>
</div>
