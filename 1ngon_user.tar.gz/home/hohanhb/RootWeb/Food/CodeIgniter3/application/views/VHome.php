<div class="content" >
	<div class="container">
		<!-- <div class="content-top">
			<h1>Sản phẩm</h1> -->
			
				<?php 
				$arr_ordered=$this->session->userdata('product_ordered');
				$arr_product_detail_standard=$this->session->userdata('product_detail_standard');
				$num=0;
				foreach($product as $list){ 
				$num++;
				if(isset($arr_product_detail_standard[$list->id_product]))
					$id_product_detail=$arr_product_detail_standard[$list->id_product];
				else
					$id_product_detail="";
				if($id_product_detail){
				?>	
				<?php if($num==1){?><div class="content-top" style="padding-bottom:0px">	<?php }?>		
					<div class="col-md-3 col-md2">
						<div class="col-md1 simpleCart_shelfItem">
							<a href="<?php echo SITE_URL."product/detail/".$list->product_name_tv;?>"><img class="img-responsive" src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$list->product_image;?>&watermark=1ngon.png" alt="<?php echo DOMAIN_NAME.", ".$list->product_name;?>"/></a>
							<h3 style=" padding-top:4px;line-height: 2ex;height: 5ex;overflow: hidden;"><a href="<?php echo SITE_URL."product/detail/".$list->product_name_tv;?>"><?php echo $list->product_name;?></a></h3>
							<div class="price">									
									<h5 class="item_price"><?php echo number_format($list->price);?></h5>
									<a id="id_add_cart[<?php echo $list->id_product;?>]" onclick="addCard('<?php echo SITE_URL;?>','<?php echo $list->id_product;?>','<?php echo $id_product_detail;?>','<?php echo $list->price;?>','1','1','1')" class="item_add"><?php if(is_array($arr_ordered) && array_key_exists($list->id_product,$arr_ordered)) echo "Đã đặt"; else echo "Đặt mua";?></a>
									
									<div class="clearfix"> </div>
							</div>							
						</div>
					</div>
					<?php if($num==4){?>
					<div class="clearfix"> </div>
					</div>
					<?php $num=0;}?>				
				<?php 
					}
				}
				?>	
			
	
		<!-- </div> //end div content-top-->
	</div>
</div>