	<title>
	<?php echo DOMAIN_NAME;?> món ngon và tiện lợi. 
	<?php if($this->uri->segment(1)=="product" || $this->uri->segment(1)=="home"){
			if($this->uri->segment(2)=="detail"){
				echo $this->session->userdata('lastest_view_product_name');
			}else{ ?>
				Gà ta bó xôi, nướng bơ, phô mai, ngũ vị, BBQ, chao quay, hấp hèm, hấp bia, nổ muối hột,...
			<?php } ?>
	<?php }elseif($this->uri->segment(1)=="news"){
			if($this->uri->segment(3)==1) echo "Giới thiệu";
			elseif($this->uri->segment(3)==2) echo "Quà tặng khi giới thiệu";
			elseif($this->uri->segment(3)==3) echo "Khu vực giao hàng";
	}?>		
	</title>
	<link href="<?php echo LAYOUT_URL; ?>css/bootstrap.css" rel="stylesheet" type="text/css" media="all" />
	<link href="<?php echo LAYOUT_URL; ?>css/support_box.css" rel="stylesheet" type="text/css" media="all" />
	<!-- jQuery (necessary for Bootstrap's JavaScript plugins) -->
	
	<script src="<?php echo LAYOUT_URL; ?>js/jquery.min.js"></script>
	<script src="<?php echo LAYOUT_URL; ?>js/support_box.js"></script>
	<!-- Custom Theme files -->
	<!--theme-style-->
	<link href="<?php echo LAYOUT_URL; ?>css/style.css" rel="stylesheet" type="text/css" media="all" />	
	<!--//theme-style-->
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<meta name="keywords" content="<?php echo DOMAIN_NAME;?>, món ăn tiện lợi, món tiệc cho gia đình, tiệc văn phòng, món ăn thịt gà, món làm quà, quà tặng buổi tiệc, món ăn làm quà tặng dịp lễ, món ăn sinh nhật, món ăn dã ngoại, gà ta bó xôi, gà ta nướng bơ, gà ta phô mai, gà ta ngũ vị, gà ta BBQ, gà ta chao quay, gà ta hấp hèm, gà ta hấp bia, gà ta nổ muối hột,..." />
	<?php if($this->uri->segment(2)<>"login2"){?>
	<script type="application/x-javascript"> addEventListener("load", function() { setTimeout(hideURLbar, 0); }, false); function hideURLbar(){ window.scrollTo(0,1); } </script>
	<!-- start menu -->
	<link href="<?php echo LAYOUT_URL; ?>css/memenu.css" rel="stylesheet" type="text/css" media="all" />
	<script type="text/javascript" src="<?php echo LAYOUT_URL; ?>js/memenu.js"></script>
	<script>$(document).ready(function(){$(".memenu").memenu();});</script>
	<script src="<?php echo LAYOUT_URL; ?>js/simpleCart.min.js"> </script>
	<!-- slide -->
	<script src="<?php echo LAYOUT_URL; ?>js/responsiveslides.min.js"></script>
	   <script>
	    $(function () {
	      $("#slider").responsiveSlides({
	      	auto: true,
	      	speed: 500,
	        namespace: "callbacks",
	        pager: true,
	      });
	    });
	  </script>
	  <?php }?>

	<script type='text/javascript'>
		var url = window.location.href;
		if(url.indexOf('1ngon.com') !== -1){
			var new_url=url.replace('1ngon.com', "1ngon.vn");
			window.location.href =new_url;
		}
	</script>
