//open popup
function openPopUp(url,windowName,width,height,url_file){
	if((width>0) && (height>0)){
		var left = (screen.width/2)-(width/2);
		var top = (screen.height/2)-(height/2);
		var newWin=window.open(url,windowName, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no,width="+width+",height="+height+', top='+top+', left='+left);
	}else{
		var width2=screen.width-200;
		var height2=screen.height-200;
		var left = (screen.width/2)-(width2/2);
		var top = (screen.height/2)-(height2/2);
		var newWin=window.open(url,windowName, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no,width="+width2+",height="+height2+', top='+top+', left='+left);
	}
	newWin.focus();
}

function loadUrl(location){
	this.document.location.href = location;
}

function openPopUp2(url,windowName,width,height){
	openmypage(url,windowName,width,height);
	ajaxwin.load('ajax', url, windowName); 
	ajaxwin.moveTo('middle', 'middle');
	return false;
} 

function openmypage(url,windowName,width,height){ //Define arbitrary function to run desired DHTML Window widget codes
	ajaxwin=dhtmlwindow.open("ajaxbox", "ajax", url, windowName, "width="+width+",height="+height+",resize=1,scrolling=0")
	//ajaxwin.onclose=function(){return window.confirm("Close window 3?")} //Run custom code when window is about to be closed
}	

function submitLogin2(SITE_URL,id_product,id_product_detail,price,quantity,taste,call_from) {
	  var txtPhone=document.getElementById('phone').value;
	  if(txtPhone==""){
		  document.getElementById("message").innerHTML="Bạn chưa nhập số điện thoại.";
		  document.getElementById("message").focus();
		  return false;
	  }
	  if (window.XMLHttpRequest) {
	    // code for IE7+, Firefox, Chrome, Opera, Safari
	    xmlhttp=new XMLHttpRequest();
	  } else {  // code for IE6, IE5
	    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
	    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	    	if(xmlhttp.responseText==1){
	    		if(call_from==1){
	    			addCard(SITE_URL,id_product,id_product_detail,price,quantity,taste,call_from);
	    		}else if(call_from==2){
	    			addCardDetail(SITE_URL,id_product);	    			
	    		}	
	    		changeLink(SITE_URL,txtPhone);
	    		parent.ajaxwin.close();	    		
	    	}else{
	    		document.getElementById("message").innerHTML="Số điện thoại không đúng.";
	  		  	document.getElementById("message").focus();
	    	}	    		
	    }
	  }
	  xmlhttp.open("GET",SITE_URL+"login/login2/"+txtPhone,true);
	  xmlhttp.send();	
}

function changeLink(URL,phone) {
    var link = document.getElementById("id_log_in");
    link.innerHTML = "Đăng xuất - "+phone;
    link.setAttribute('href', URL+"login/logout/");
    var link2 = document.getElementById("id_cart");
    link2.innerHTML = "Giỏ hàng";
    return false;
}

//refresh window
function refresh() {
    window.opener.location.reload(true);
    
}

//refresh and close window
function refreshAndClose() {
    window.opener.location.reload(true);
    window.close();
}

function del(id){
	if(confirm('Bạn có thật sự muốn xóa?')){
		return true;
	}	
	return false;
}

function update(id){
	if(confirm('Bạn có thật sự muốn sửa đơn hàng?')){
		return true;
	}	
	return false;
}

function addCard(SITE_URL,id_product,id_product_detail='',price_detail='',quantity=1,taste=1,call_from=1) {
		  if(quantity.trim().length>0){
			  if(isNaN(quantity)){ 
				  quantity=1;
			  } 
		  }else
			  quantity=1;
		  if (window.XMLHttpRequest) {
		    // code for IE7+, Firefox, Chrome, Opera, Safari
		    xmlhttp=new XMLHttpRequest();
		  } else {  // code for IE6, IE5
		    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  xmlhttp.onreadystatechange=function() {
		    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		    	if(xmlhttp.responseText==-1){
		    		openPopUp2(SITE_URL+"login/login2/","1Ngon",300,250);
		    		return false;
		    	}
		    	elem = document.getElementById('id_add_cart['+id_product+']');
		    	elem.innerHTML = "Đã đặt";
		    	elem = document.getElementById('id_price_total');
		    	elem.innerHTML = xmlhttp.responseText;
		    	elem = document.getElementById('id_cart');
		    	elem.innerHTML = "Giỏ hàng";
		    	
		    }
		  }
		  xmlhttp.open("GET",SITE_URL+"product/order/"+id_product+"/"+id_product_detail+"/"+price_detail+"/"+quantity+"/"+taste+"/"+call_from,true);
		  xmlhttp.send();	
}

function addCardDetail(SITE_URL,id_product) {		
	var arr_order_select = document.getElementsByName("order_select");
	var arr_order_price = document.getElementsByName("order_price");
	var arr_order_quantity = document.getElementsByName("order_quantity");
	var order_taste = document.getElementById("order_taste").value;
	var call_from=2;
	var len = arr_order_select.length;
    for (var i=0; i<len; i++) {
        //alert(i + (arr_order_select[i].checked?' checked ':' unchecked ') + arr_order_select[i].value);
    	if(arr_order_select[i].checked){
    		//addCard(SITE_URL,id_product,id_product_detail='',price_detail='',quantity=1,taste=1)
    		addCard(SITE_URL,id_product,arr_order_select[i].value,arr_order_price[i].value,arr_order_quantity[i].value,order_taste,call_from);
    	}
    }   	
}

function editCard(SITE_URL,id_product_order,id_product,id_product_detail,price) {
	var order_quantity=document.getElementById("quantity["+id_product_order+"]").value;
	if(order_quantity>0){
		  if (window.XMLHttpRequest) {
		    // code for IE7+, Firefox, Chrome, Opera, Safari
		    xmlhttp=new XMLHttpRequest();
		  } else {  // code for IE6, IE5
		    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  xmlhttp.onreadystatechange=function() {
		    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		    	elem = document.getElementById('money['+id_product_order+']');
		    	var tmp=price*order_quantity;
		    	elem.innerHTML = number_format(tmp);
		    	
		    	elem = document.getElementById('money_total');
		    	elem.innerHTML = xmlhttp.responseText;
		    	
		    	elem = document.getElementById('id_price_total');
		    	elem.innerHTML = xmlhttp.responseText;
		    }
		  }
		  xmlhttp.open("GET",SITE_URL+"product/editcard/"+id_product_order+"/"+id_product+"/"+id_product_detail+"/"+price+"/"+order_quantity,true);
		  xmlhttp.send();
		   
		}else{
			document.getElementById("quantity["+id_product_order+"]").value=1;
		}
}

function deleteCard(SITE_URL,id_product_order,id_product,id_product_detail,num) {
	  if (window.XMLHttpRequest) {
	    // code for IE7+, Firefox, Chrome, Opera, Safari
	    xmlhttp=new XMLHttpRequest();
	  } else {  // code for IE6, IE5
	    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
	    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	    	elem = document.getElementById('money_total');
	    	elem.innerHTML = xmlhttp.responseText;
	    	
	    	elem = document.getElementById('id_price_total');
	    	elem.innerHTML = xmlhttp.responseText;
	    	deleteRow(num);
	    }
	  }
	  xmlhttp.open("GET",SITE_URL+"product/deletecard/"+id_product_order+"/"+id_product+"/"+id_product_detail,true);
	  xmlhttp.send();
		   
		
}

function deleteRow(num) {
    document.getElementById("CheckOutTable").deleteRow(num);
}

function confirmCard(SITE_URL) {
	
	var address=document.getElementById("address").value;
	var phone=document.getElementById("phone").value;
	var note=document.getElementById("note").value;
	if(phone==''){
		document.getElementById("message").innerHTML="Vui lòng nhập số điện thoại liên hệ.";
		document.getElementById("phone").focus();
		return false;
	}else if(isNaN(phone.replace(/ /g,''))){				
		document.getElementById("message").innerHTML="Số điện thoại không đúng.";
		document.getElementById("phone").focus();
		return false;
	}
	
	if(address==''){
		document.getElementById("message").innerHTML="Vui lòng nhập địa chỉ giao hàng.";
		document.getElementById("address").focus();
		return false;
	}
	document.forms['myForm'].submit();	
}

function nextCard(SITE_URL) {
	window.location=SITE_URL+"product/confirmcard/";
}

function number_format(number,decimals,dec_point,thousands_sep) {
    var str = number.toFixed(decimals?decimals:0).toString().split('.');
    var parts = [];
    for ( var i=str[0].length; i>0; i-=3 ) {
        parts.unshift(str[0].substring(Math.max(0,i-3),i));
    }
    str[0] = parts.join(thousands_sep?thousands_sep:',');
    return str.join(dec_point?dec_point:'.');
}

function writeLog(SITE_URL,title,type,status) {	
	  if (window.XMLHttpRequest) {
	    // code for IE7+, Firefox, Chrome, Opera, Safari
	    xmlhttp=new XMLHttpRequest();
	  } else {  // code for IE6, IE5
	    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
	    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	    	
	    }
	  }
	  xmlhttp.open("GET",SITE_URL+"product/writelog/"+title+"/"+type+"/"+status,true);
	  xmlhttp.send();

}




