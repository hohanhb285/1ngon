<script>
// AddPaymentInfo
// Track when payment information is added in the checkout flow (ex. click/landing page on billing info)
fbq('track', 'AddPaymentInfo');
</script>
<div class="container">
	<div class="check-out">
		<h1>Thông tin đơn hàng</h1>
    	   
			<table id="CheckOutTable">
		  <tr>
		  	<th>1.Sản phẩm</th>		  	
			<th>SL</th>		
			<th>Giá</th>
			<th>Thành tiền</th>			
		  </tr>
		  <?php 
		  function get_words($sentence, $count = 10) {
			  preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
			  return $matches[0];
			}
			
		  	$num=0;
		  	$money_total=0;
		  	foreach($product_ordered as $list){ 
			$num++;?>
		  <tr>
			<td class="ring-in"><a href="<?php echo SITE_URL.'product/detail/'.$list->product_name_tv;?>" class="at-in"><img src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$list->product_image;?>&watermark=1ngon.png" class="img-responsive" alt=""></a>
			<div class="sed">
				<h5><?php echo $list->product_name;?></h5>
				<!-- <p><?php //echo get_words($list->description,30);?></p> -->
				<p><?php echo $list->product_name_detail;?></p>
				<p><?php echo $list->detail_size;?></p>
				<!-- <?php //if($list->detail_note){ ?><p><?php //echo $list->detail_note;?></p><?php //}?>-->
			</div>
			<div class="clearfix"> </div></td>			
			<td class="check"><?php echo $list->quantity;?></td>		
			<td><div id="price[<?php echo $list->id_product_order;?>]"><?php echo number_format($list->price);?></div></td>
			<?php $money_sum=$list->quantity*$list->price; $money_total=$money_total+$money_sum;?>
			<td><div id="money[<?php echo $list->id_product_order;?>]"><?php echo number_format($money_sum);?></div></td>
			
		  </tr>
		  <?php }?>
		  <tr>
		  <td></td>
		  <th colspan="2">Tiền sản phẩm</th>
		  <th><div id="money_total"><strong><?php echo number_format($money_total);?></strong></div></th>
		  </tr>
		  <tr>
		  	<th>2.Khách hàng</th>		  	
			<th></th>		
			<th></th>
			<th>Phí</th>			
		  </tr>
		  <?php 
		  $arr_customer_info=$this->session->userdata('customer_info');
		  $arr_ship_fee_info=$this->session->userdata('ship_fee_info');
		  ?>
		  <tr>
		  	<th class="ring-in">Quận/Huyện</th>	
		  	<th></th>	  	
			<td><div>
				<h5><?php echo $arr_ship_fee_info['district_name'];?></h5>
				<p></p>
			</div>
			<div class="clearfix"> </div></td>
			<td><?php if($arr_ship_fee_info['ship_fee']) echo number_format($arr_ship_fee_info['ship_fee']); else echo "Miễn phí";?></td>			
		  </tr>
		  <tr>
		  	<th class="ring-in">Điện thoại</th>	
		  	<th></th>		  	
			<td colspan="2" style="text-align:left"><div>
				<h5><?php echo $arr_customer_info['phone'];?></h5>
				<p></p>
			</div>
			<div class="clearfix"> </div></td>		
		  </tr>
		  <tr>
		  	<th class="ring-in">Địa chỉ</th>	
		  	<th></th>	  	
			<td colspan="2"><?php echo $arr_customer_info['address'];?>
			<div class="clearfix"> </div></td>
		  </tr>
		  <tr>
		  	<th class="ring-in">Ghi chú thêm</th>
		  	<th></th>		  	
			<td colspan="2"><?php echo $arr_customer_info['note'];?>
			<div class="clearfix"> </div></td>				
		  </tr>
		  <tr>
		  <td></td>
		  <th colspan="2">Phí giao hàng</th>
		  <th><div id="money_total"><strong><?php if($arr_ship_fee_info['ship_fee']) echo number_format($arr_ship_fee_info['ship_fee']); else echo "Miễn phí";?></strong></div></th>
		  </tr>
		  <tr>
		  <td></td>
		  <th colspan="2"><strong>Tổng tiền(1+2)</strong></th>
		  <th><div id="money_total"><strong><?php $money_total2=$money_total+$arr_ship_fee_info['ship_fee'];echo number_format($money_total2);?></strong></div></th>
		  </tr>
	</table>
	<div style="text-align: center">Chúng tôi sẽ liên hệ xác nhận đơn hàng và giao hàng cho bạn.<br/> Cám ơn bạn đã tin dùng dịch vụ của 1Ngon chúng tôi.</div>	
	<div class="clearfix"> </div>
	
	</div>
</div>