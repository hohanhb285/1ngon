<div class="container">
	<div class="check-out">
	<h1>Đăng ký</h1>
	<form id="frmName" method="post" accept-charset="utf-8">
	<table>
		  <tr>
		  	<th></th>
		  	<th></th>
		  	<th></th>
			<th><div id="message" style="color:red">
				<?php 
					if($result==0)
						echo "Bạn chưa nhập đầy đủ thông tin.";
					elseif($result==2)
						echo "Số điện thoại không đúng.";
					elseif($result==1){
						//var_dump($this->session->userdata('customer_info'));
					}
							
				?>
				</div></th>		
			<th></th>			
		  </tr>	
		  <tr>
		  	<th></th>
		  	<th></th>
		  	<th style="text-align:right">Số điện thoại</th>
			<th> <input type="text" name="phone"/><input type="text" name="testtest"/></th>		
			<th></th>			
		  </tr>
		  <tr>
		  	<th></th>
		  	<th></th>
		  	<th style="text-align:right">Email</th>
			<th> <input type="text" name="Email"/><input type="text" name="testtest"/></th>		
			<th></th>			
		  </tr>	
		  <tr>
		  	<th></th>
		  	<th></th>
		  	<th></th>
			<th><input type="submit" name="btn_Submit" value="Đăng nhập"/> <input type="reset" name="btn_Reset" value="Nhập lại"/></th>		
			<th></th>
		  </tr>		  
	</table>
	
	</form>	<div class="clearfix"> </div>		
	</div>
</div>