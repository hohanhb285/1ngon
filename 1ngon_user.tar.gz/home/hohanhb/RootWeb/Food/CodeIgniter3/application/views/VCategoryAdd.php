<html>
<head>
	<title>Add category</title>
	<style>
		.error{			
			color:red;
		}
	</style>
</head>
<body>
<?php echo validation_errors(); ?>

<?php 
echo form_open("category/submit_add/");?>
Add more Category:<br>
Category name: <input type="text" name="txt_category_name" value="<?php echo set_value('txt_category_name'); ?>">
<br>
Email: <input type="text" name="txt_email" value="<?php echo set_value('txt_email'); ?>"> 
<br>
Phone: <input type="text" name="txt_phone" value="<?php echo set_value('txt_phone'); ?>"> 
<br>
<input type="submit" name="sm" value="Submit">
 
<?php echo form_close(); ?>	
</body>	
</html>