<!--just Liked-->
				<div class="product-bottom">
						<h3 class="cate">Sản phẩm yêu thích</h3>
					<?php 
					if(isset($liked_product)){
					foreach($liked_product as $liked_product_list){
					?>
					<div class="product-go">
						<div class=" fashion-grid">
							<a href="<?php echo $liked_product_list->product_name_tv;?>"><img class="img-responsive " src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$liked_product_list->product_image;?>&watermark=1ngon.png" alt=""></a>	
						</div>
						<div class=" fashion-grid1">
							<h6 class="best2"><a href="<?php echo $liked_product_list->product_name_tv;?>" ><?php echo $liked_product_list->product_name;?></a></h6>
							<span class=" price-in1"> <?php echo number_format($liked_product_list->price);?></span>
						</div>	
						<div class="clearfix"> </div>
					</div>
					<?php }}?>						
				</div>			
<!--End Just Liked-->

