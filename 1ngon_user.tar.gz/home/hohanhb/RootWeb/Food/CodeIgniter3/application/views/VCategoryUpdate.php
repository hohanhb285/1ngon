<?php 
echo form_open("category/submit_update/");?>
Update Category:<br>
<?php //var_dump($category);?>
Category name: <input type="text" name="txt_category_name" value="<?php echo $category->name;?>"> <input type="submit" name="sm" value="Submit">
<input type="hidden" name="txt_category_id" value="<?php echo $category->id;?>">
<?php echo form_close(); ?>		
