<div class="content">
	<div class="container">
		<!-- <div class="content-top">
			<h1>Sản phẩm</h1> -->
			<div class="content-top1">
				<?php 
				$arr_ordered=$this->session->userdata('product_ordered');
				$num=0;
				foreach($product as $list){ 
				$num++;
				?>	
				<?php if($num==1){?><div class="content-top1">	<?php }?>		
					<div class="col-md-3 col-md2">
						<div class="col-md1 simpleCart_shelfItem">
							<a href="<?php echo SITE_URL."product/detail/".$list->id_product;?>"><img class="img-responsive" src="<?php echo LAYOUT_URL.'images_product/'.$list->product_image;?>" alt="<?php echo DOMAIN_NAME.", ".$list->product_name;?>" /></a>
							<h3 style=" padding-top:4px;line-height: 2ex;height: 4ex;overflow: hidden;"><a href="<?php echo SITE_URL."product/detail/".$list->id_product;?>"><?php echo $list->product_name;?></a></h3>
							
							<div class="price">
									<h5 class="item_price"><?php echo number_format($list->price);?></h5>
									<a id="id_add_cart[<?php echo $list->id_product;?>]" onclick="addCard('<?php echo SITE_URL;?>','<?php echo $list->id_product;?>','<?php echo $list->price;?>')" class="item_add"><?php if(is_array($arr_ordered) && array_key_exists($list->id_product,$arr_ordered)) echo "Đã đặt"; else echo "Đặt mua";?></a>
									
									<div class="clearfix"> </div>
							</div>
							
						</div>
					</div>
					<?php if($num==4){?>
					<div class="clearfix"> </div>
					</div>
					<?php $num=0;}?>				
				<?php }?>	
			
			
			</div>	
		<!-- </div> //end div content-top-->
	</div>
</div>