<!--tag-->
				<div class="tag">	
					<h3 class="cate">Tags</h3>
					<div class="tags">
						<ul>
							<li><a href="<?php echo SITE_URL."product/"; ?>">Món ăn bữa tiệc</a></li>
							<li><a href="<?php echo SITE_URL."product/"; ?>">Món ăn liên hoan</a></li>
							<li><a href="<?php echo SITE_URL."product/"; ?>">Món sinh nhật</a></li>
							<li><a href="<?php echo SITE_URL."product/"; ?>">Món ăn quà tặng</a></li>
							<?php 
							if(isset($other_product)){
								foreach($other_product as $other_product_list){
									$tok = explode(" ",$other_product_list->product_name,6);
									$str_product_name="";
									if(count($tok)>=5)
										$n=5;
									else
										$n=count($tok);
									for($i=0;$i<$n;$i++)
										$str_product_name=$str_product_name." ".$tok[$i];
										
							?>
							<li><a title="<?php echo $other_product_list->product_name;?>" href="<?php echo SITE_URL."product/detail/".$other_product_list->product_name_tv;?>"><?php echo $str_product_name;?></a></li>
							<?php }}?>													
						<div class="clearfix"> </div>
						</ul>
					</div>					
				</div>