<?php $this->view('VLicense');?>
<!DOCTYPE html>
<html>

<head>
	<!-- Facebook Pixel Code -->
	<script>
	!function(f,b,e,v,n,t,s){if(f.fbq)return;n=f.fbq=function(){n.callMethod?
	n.callMethod.apply(n,arguments):n.queue.push(arguments)};if(!f._fbq)f._fbq=n;
	n.push=n;n.loaded=!0;n.version='2.0';n.queue=[];t=b.createElement(e);t.async=!0;
	t.src=v;s=b.getElementsByTagName(e)[0];s.parentNode.insertBefore(t,s)}(window,
	document,'script','https://connect.facebook.net/en_US/fbevents.js');
	
	fbq('init', '312978519037152');
	fbq('track', "PageView");</script>
	<noscript><img height="1" width="1" style="display:none"
	src="https://www.facebook.com/tr?id=312978519037152&ev=PageView&noscript=1"
	/></noscript>
	<!-- End Facebook Pixel Code -->

	<?php $this->view('VHead');?>

	<?php //if($this->uri->segment(2)<>"login2"){?>
	<!--Start of Zopim Live Chat Script-->
		<script type="text/javascript">
		/* window.$zopim||(function(d,s){var z=$zopim=function(c){z._.push(c)},$=z.s=
		d.createElement(s),e=d.getElementsByTagName(s)[0];z.set=function(o){z.set.
		_.push(o)};z._=[];z.set._=[];$.async=!0;$.setAttribute("charset","utf-8");
		$.src="//v2.zopim.com/?3x7CIFW3FqhIgRmQW4OpxiKw7Vlz6UF7";z.t=+new Date;$.
		type="text/javascript";e.parentNode.insertBefore($,e)})(document,"script");
		*/
		</script>
	<!--End of Zopim Live Chat Script-->
	<?php //}?>

	<?php if($_SERVER['HTTP_HOST']=="1ngon.vn"){?>
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
		
		  ga('create', 'UA-78355465-1', 'auto');
		  ga('send', 'pageview');
		
		</script>
	<?php }else{?>
		<script>
		  (function(i,s,o,g,r,a,m){i['GoogleAnalyticsObject']=r;i[r]=i[r]||function(){
		  (i[r].q=i[r].q||[]).push(arguments)},i[r].l=1*new Date();a=s.createElement(o),
		  m=s.getElementsByTagName(o)[0];a.async=1;a.src=g;m.parentNode.insertBefore(a,m)
		  })(window,document,'script','https://www.google-analytics.com/analytics.js','ga');
		
		  ga('create', 'UA-78355465-2', 'auto');
		  ga('send', 'pageview');
		
		</script>
				
	<?php }?>
	
	
	
	<?php if(!$this->uri->segment(1) || $this->uri->segment(1)=="product" || $this->uri->segment(1)=="home"){?>
	<link rel="stylesheet" href="<?php echo LAYOUT_URL; ?>js/dhtmlwindow/windowfiles/dhtmlwindow.css" type="text/css" />	
	<script type="text/javascript" src="<?php echo LAYOUT_URL; ?>js/dhtmlwindow/windowfiles/dhtmlwindow.js">
	
	/***********************************************
	* DHTML Window Widget- © Dynamic Drive (www.dynamicdrive.com)
	* This notice must stay intact for legal use.
	* Visit http://www.dynamicdrive.com/ for full source code
	***********************************************/
	
	</script>
	<?php }?>
	
	<script src="<?php echo LAYOUT_URL; ?>js/common3.js"></script>
	
</head>

<body>
	<div id="fb-root"></div>
	<script>(function(d, s, id) {
	  var js, fjs = d.getElementsByTagName(s)[0];
	  if (d.getElementById(id)) return;
	  js = d.createElement(s); js.id = id;
	  js.src = "//connect.facebook.net/vi_VN/sdk.js#xfbml=1&version=v2.6&appId=1619156468401519";
	  fjs.parentNode.insertBefore(js, fjs);
	}(document, 'script', 'facebook-jssdk'));
	</script>
	
	<?php if($this->uri->segment(2)<>"login2"){?>
		<!--header-->
		<?php $this->view('VHeader');?>
		<!--end header-->
	<?php }?>
	
	<!--banner-->
	<?php if($this->uri->segment(1)=='' || $this->uri->segment(1)=='product' || $this->uri->segment(1)=='home') //$this->view('VBanner_carousel_slider'); //carousel_slider?>
	<!--end banner-->

	<!--content-->
	<?php echo $content;?>	
	<!--end content-->
	
	<!--Support chat box-->
	<?php if($this->uri->segment(2)<>"login2"){?>
		<?php $this->view('VSupportBox');?>	
	<?php }?>
	<!--end support chat box-->
	
	<?php if($this->uri->segment(2)<>"login2"){?>
		<!--footer-->
		<div style="padding-top:25px;"></div>
		<?php $this->view('VFooter');?>
		<!--end footer-->
	<?php }?>
	<!-- Google Code dành cho Thẻ tiếp thị lại -->
	<!--------------------------------------------------
	Không thể liên kết thẻ tiếp thị lại với thông tin nhận dạng cá nhân hay đặt thẻ tiếp thị lại trên các trang có liên quan đến danh mục nhạy cảm. Xem thêm thông tin và hướng dẫn về cách thiết lập thẻ trên: http://google.com/ads/remarketingsetup
	--------------------------------------------------->
	<script type="text/javascript">
	/* <![CDATA[ */
	var google_conversion_id = 875731739;
	var google_custom_params = window.google_tag_params;
	var google_remarketing_only = true;
	/* ]]> */
	</script>
	<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
	</script>
	<noscript>
	<div style="display:inline;">
	<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/875731739/?value=0&amp;guid=ON&amp;script=0"/>
	</div>
	</noscript>
</body>
</html>