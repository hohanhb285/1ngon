//open popup
function openPopUp(url,windowName,width,height,url_file){
	if((width>0) && (height>0)){
		var left = (screen.width/2)-(width/2);
		var top = (screen.height/2)-(height/2);
		var newWin=window.open(url,windowName, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no,width="+width+",height="+height+', top='+top+', left='+left);
	}else{
		var width2=screen.width-200;
		var height2=screen.height-200;
		var left = (screen.width/2)-(width2/2);
		var top = (screen.height/2)-(height2/2);
		var newWin=window.open(url,windowName, "toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=no, copyhistory=no,width="+width2+",height="+height2+', top='+top+', left='+left);
	}
	newWin.focus();
}

function loadUrl(location){
	this.document.location.href = location;
}

//refresh window
function refresh() {
    window.opener.location.reload(true);
    
}

//refresh and close window
function refreshAndClose() {
    window.opener.location.reload(true);
    window.close();
}

function del(id){
	if(confirm('Bạn có thật sự muốn xóa?')){
		return true;
	}	
	return false;
}

function update(id){
	if(confirm('Bạn có thật sự muốn sửa đơn hàng?')){
		return true;
	}	
	return false;
}

function addCard(SITE_URL,id_product,price) {		 
		  if (window.XMLHttpRequest) {
		    // code for IE7+, Firefox, Chrome, Opera, Safari
		    xmlhttp=new XMLHttpRequest();
		  } else {  // code for IE6, IE5
		    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  xmlhttp.onreadystatechange=function() {
		    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		    	elem = document.getElementById('id_add_cart['+id_product+']');
		    	elem.innerHTML = "Đã đặt";
		    	elem = document.getElementById('id_price_total');
		    	elem.innerHTML = xmlhttp.responseText;
		    	elem = document.getElementById('id_cart');
		    	elem.innerHTML = "Giỏ hàng";
		    	
		    }
		  }
		  xmlhttp.open("GET",SITE_URL+"product/order/"+id_product+"/"+price,true);
		  xmlhttp.send();	
}

function editCard(SITE_URL,id_product_order,price) {
	var order_quantity=document.getElementById("quantity["+id_product_order+"]").value;
	if(order_quantity>0){
		  if (window.XMLHttpRequest) {
		    // code for IE7+, Firefox, Chrome, Opera, Safari
		    xmlhttp=new XMLHttpRequest();
		  } else {  // code for IE6, IE5
		    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
		  }
		  xmlhttp.onreadystatechange=function() {
		    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
		    	elem = document.getElementById('money['+id_product_order+']');
		    	var tmp=price*order_quantity;
		    	elem.innerHTML = number_format(tmp);
		    	
		    	elem = document.getElementById('money_total');
		    	elem.innerHTML = xmlhttp.responseText;
		    	
		    	elem = document.getElementById('id_price_total');
		    	elem.innerHTML = xmlhttp.responseText;
		    }
		  }
		  xmlhttp.open("GET",SITE_URL+"product/editcard/"+id_product_order+"/"+order_quantity,true);
		  xmlhttp.send();
		   
		}else{
			document.getElementById("quantity["+id_product_order+"]").value=1;
		}
}

function deleteCard(SITE_URL,id_product_order,num,id_product) {
	  if (window.XMLHttpRequest) {
	    // code for IE7+, Firefox, Chrome, Opera, Safari
	    xmlhttp=new XMLHttpRequest();
	  } else {  // code for IE6, IE5
	    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
	    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	    	elem = document.getElementById('money_total');
	    	elem.innerHTML = xmlhttp.responseText;
	    	
	    	elem = document.getElementById('id_price_total');
	    	elem.innerHTML = xmlhttp.responseText;
	    	deleteRow(num);
	    }
	  }
	  xmlhttp.open("GET",SITE_URL+"product/deletecard/"+id_product_order+"/"+id_product,true);
	  xmlhttp.send();
		   
		
}

function deleteRow(num) {
    document.getElementById("CheckOutTable").deleteRow(num);
}

function confirmCard(SITE_URL) {
	
	var address=document.getElementById("address").value;
	var phone=document.getElementById("phone").value;
	var note=document.getElementById("note").value;
	if(phone==''){
		document.getElementById("message").innerHTML="Vui lòng nhập số điện thoại liên hệ.";
		document.getElementById("phone").focus();
		return false;
	}else if(isNaN(phone.replace(/ /g,''))){				
		document.getElementById("message").innerHTML="Số điện thoại không đúng.";
		document.getElementById("phone").focus();
		return false;
	}
	
	if(address==''){
		document.getElementById("message").innerHTML="Vui lòng nhập địa chỉ giao hàng.";
		document.getElementById("address").focus();
		return false;
	}
	document.forms['myForm'].submit();	
}

function nextCard(SITE_URL) {
	window.location=SITE_URL+"product/confirmcard/";
}

function number_format(number,decimals,dec_point,thousands_sep) {
    var str = number.toFixed(decimals?decimals:0).toString().split('.');
    var parts = [];
    for ( var i=str[0].length; i>0; i-=3 ) {
        parts.unshift(str[0].substring(Math.max(0,i-3),i));
    }
    str[0] = parts.join(thousands_sep?thousands_sep:',');
    return str.join(dec_point?dec_point:'.');
}

function writeLog(SITE_URL,title,type,status) {	
	  if (window.XMLHttpRequest) {
	    // code for IE7+, Firefox, Chrome, Opera, Safari
	    xmlhttp=new XMLHttpRequest();
	  } else {  // code for IE6, IE5
	    xmlhttp=new ActiveXObject("Microsoft.XMLHTTP");
	  }
	  xmlhttp.onreadystatechange=function() {
	    if (xmlhttp.readyState==4 && xmlhttp.status==200) {
	    	
	    }
	  }
	  xmlhttp.open("GET",SITE_URL+"product/writelog/"+title+"/"+type+"/"+status,true);
	  xmlhttp.send();

}




