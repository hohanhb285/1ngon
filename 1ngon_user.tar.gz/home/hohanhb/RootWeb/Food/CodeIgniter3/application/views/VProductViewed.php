<!--just viewed-->
				<div class="product-bottom">
						<h3 class="cate">Sản phẩm vừa xem</h3>
					<?php 
					$arr_viewed=$this->session->userdata('product_viewed_list');
					if($arr_viewed){
						$arr_viewed=array_reverse($arr_viewed,true);
					foreach($arr_viewed as $key=>$value){
					?>
					<div class="product-go">
						<div class=" fashion-grid">
							<a href="<?php echo $value[$key]->product_name_tv;?>"><img class="img-responsive " src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$value[$key]->product_image;?>&watermark=1ngon.png" alt=""></a>	
						</div>
						<div class=" fashion-grid1">
							<h6 class="best2"><a href="<?php echo $value[$key]->product_name_tv;?>" ><?php echo $value[$key]->product_name;?></a></h6>
							<span class=" price-in1"> <?php echo number_format($value[$key]->price);?></span>
						</div>	
						<div class="clearfix"> </div>
					</div>
					<?php }}?>						
				</div>
<!--end just viewed-->


