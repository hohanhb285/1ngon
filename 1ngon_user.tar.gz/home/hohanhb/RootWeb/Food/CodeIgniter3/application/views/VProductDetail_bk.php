<div class="single">
<div class="container">

<div class="col-md-9">
	<?php 
	if(isset($product)){
		$arr_viewed=$this->session->userdata('product_viewed_list');
		if(is_array($arr_viewed)){
			if(!array_key_exists($product->id_product,$arr_viewed))
				$arr_viewed[$product->id_product]=array($product->id_product=>$product);
		}else
			$arr_viewed[$product->id_product]=array($product->id_product=>$product);
		$this->session->set_userdata('product_viewed_list',$arr_viewed);
		//$this->session->unset_userdata('product_viewed_list');
	?>
	<div class="col-md-5 grid">		
		<div class="flexslider">
			  <ul class="slides">
			  	
			    <li data-thumb="<?php echo LAYOUT_URL.'images_product/'.$product->product_image1;?>">
			        <div class="thumb-image"> <img src="<?php echo LAYOUT_URL.'images_product/'.$product->product_image1;?>" data-imagezoom="true" class="img-responsive"> </div>
			    </li>
			    <li data-thumb="<?php echo LAYOUT_URL.'images_product/'.$product->product_image2;?>">
			        <div class="thumb-image"> <img src="<?php echo LAYOUT_URL.'images_product/'.$product->product_image2;?>" data-imagezoom="true" class="img-responsive"> </div>
			    </li>
			    <li data-thumb="<?php echo LAYOUT_URL.'images_product/'.$product->product_image3;?>">
			        <div class="thumb-image"> <img src="<?php echo LAYOUT_URL.'images_product/'.$product->product_image3;?>" data-imagezoom="true" class="img-responsive"> </div>
			    </li> 
			  </ul>
		</div>
	</div>	
	<div class="col-md-7 single-top-in">
						<div class="single-para simpleCart_shelfItem">
						<?php $this->session->set_userdata('lastest_view_product_name',$product->product_name);?>
							<h1><?php echo $product->product_name;?></h1>
							<p><?php echo $product->description;?></p>
							<!-- <div class="star-on">
								<ul>
									<?php 
									$rand=rand(3,5);
									for($i=0;$i<$rand;$i++){?>
									<li><a href="#"><i class="glyphicon glyphicon-star"></i></a></li>
									<?php }?>
								</ul>
								<div class="review">
									<a href="#"> 3 reviews </a>/
									<a href="#">  Write a review</a>
								</div>
							<div class="clearfix"> </div>
							</div>-->
							
							<label  class="add-to item_price"><?php echo number_format($product->price);?></label>
							
							<!-- <div class="available">
								<h6>Available Options :</h6>
								<ul>
									
								<li>Size:<select>
									<option>Large</option>
									<option>Medium</option>
									<option>small</option>
									<option>Large</option>
									<option>small</option>
								</select></li>
								<li>Cost:
										<select>
										<option>U.S.Dollar</option>
										<option>Euro</option>
									</select></li>
									</ul>
								</div> 
								<a href="#" class="cart item_add">Chi tiết</a>-->
								<?php $arr_ordered=$this->session->userdata('product_ordered');?>
								<a class="cart item_add" id="id_add_cart[<?php echo $product->id_product;?>]" onclick="addCard('<?php echo SITE_URL;?>','<?php echo $product->id_product;?>','<?php echo $product->price;?>')" class="item_add"><?php if(is_array($arr_ordered) && array_key_exists($product->id_product,$arr_ordered)) echo "Đã đặt"; else echo "Đặt mua";?></a>
								<a class="cart item_add" onclick="feedToWall()">f chia sẻ</a>								
								<div id='fb-root'></div>
								<script>
									  window.fbAsyncInit = function() {
									    FB.init({
										  <?php if($_SERVER['HTTP_HOST']=='1ngon.vn'){?>
									      appId      : '1154466961282709',
									      <?php }elseif($_SERVER['HTTP_HOST']=='1ngon.com'){?>
									      appId      : '276848525992952',
									      <?php }else{?>
									      appId      : '1012147018834088',
									      <?php }?>
									      xfbml      : true,
									      version    : 'v2.6'
									    });
									  };
									
									  (function(d, s, id){
									     var js, fjs = d.getElementsByTagName(s)[0];
									     if (d.getElementById(id)) {return;}
									     js = d.createElement(s); js.id = id;
									     js.src = "//connect.facebook.net/en_US/sdk.js";
									     fjs.parentNode.insertBefore(js, fjs);
									   }(document, 'script', 'facebook-jssdk'));

								      function feedToWall() {
								         FB.ui({
								             method: 'feed',
								             link: '<?php echo SITE_URL.'product/detail/'.$product->id_product;?>',
								             picture: '<?php echo LAYOUT_URL.'images_product/'.$product->product_thumb;?>',
								             name: '<?php echo $product->product_name.". Giá:".($product->price/1000)."k";?>',
								             description: '<?php echo strip_tags($product->description);?>',
								             caption: '<?php echo $_SERVER['HTTP_HOST']?> - Món ăn ngon và tiện lợi.'								             
								         }, function(response) {
								             // check feed to wall
								             if (response && response.post_id) {
								                 location.href = '<?php echo SITE_URL.'product/detail/'.$product->id_product;?>';
								                 writeLog('<?php echo SITE_URL;?>','<?php echo $_SERVER['HTTP_HOST']."_".$product->id_product;?>','share_product_detail',1);
								             } else {
								            	 writeLog('<?php echo SITE_URL;?>','<?php echo $_SERVER['HTTP_HOST']."_".$product->id_product;?>','share_product_detail',0);
								             }
								         });
								     };
								    
								</script>
						</div>
				</div>
			<?php 
				}	
			?>
			<div class="clearfix"> </div>
			
			<!-- Other product -->
			<div class="content-top1">
				<?php 
					if(isset($other_product)){
					foreach($other_product as $other_product_list){
					?>
				<div class="col-md-4 col-md3">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="<?php echo $other_product_list->id_product;?>">
							<img class="img-responsive" src="<?php echo LAYOUT_URL.'images_product/'.$other_product_list->product_image;?>" alt="" />
						</a>
						<h3><a href="<?php echo $other_product_list->id_product;?>"><?php echo $other_product_list->product_name;?></a></h3>
						<div class="price">
								<h5 class="item_price"><?php echo number_format($other_product_list->price);?></h5>
								<a class="cart item_add" id="id_add_cart[<?php echo $other_product_list->id_product;?>]" onclick="addCard('<?php echo SITE_URL;?>','<?php echo $other_product_list->id_product;?>','<?php echo $other_product_list->price;?>')" class="item_add"><?php if(is_array($arr_ordered) && array_key_exists($other_product_list->id_product,$arr_ordered)) echo "Đã đặt"; else echo "Đặt mua";?></a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<?php }}?>	
			<div class="clearfix"> </div>
			</div>
			<!-- End other product -->
		</div>
		<!-- Product Liked ,Viewed, Tag-->
		<div class="col-md-3 product-bottom">
			<?php $this->view('VProductLiked');?>
			<?php $this->view('VProductViewed');?>
			<?php $this->view('VTag');?>			
		</div>
		<div class="clearfix"> </div>
		<!-- End product Liked ,Viewed, Tag-->
	</div>
</div>

<!-- slide -->
<script src="<?php echo LAYOUT_URL; ?>js/imagezoom.js"></script>
<!--initiate accordion-->
<script type="text/javascript">
	$(function() {
	    var menu_ul = $('.menu-drop > li > ul'),
	           menu_a  = $('.menu-drop > li > a');
	    menu_ul.hide();
	    menu_a.click(function(e) {
	        e.preventDefault();
	        if(!$(this).hasClass('active')) {
	            menu_a.removeClass('active');
	            menu_ul.filter(':visible').slideUp('normal');
	            $(this).addClass('active').next().stop(true,true).slideDown('normal');
	        } else {
	            $(this).removeClass('active');
	            $(this).next().stop(true,true).slideUp('normal');
	        }
	    });
	
	});
</script>
<!-- FlexSlider -->
<script defer src="<?php echo LAYOUT_URL; ?>js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="<?php echo LAYOUT_URL; ?>css/flexslider.css" type="text/css" media="screen" />

<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>

<!---pop-up-box---->
<link href="<?php echo LAYOUT_URL; ?>css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
<script src="<?php echo LAYOUT_URL; ?>js/jquery.magnific-popup.js" type="text/javascript"></script>
<!---//pop-up-box---->
 <script>
	$(document).ready(function() {
		$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
		});																	
	});
</script>



