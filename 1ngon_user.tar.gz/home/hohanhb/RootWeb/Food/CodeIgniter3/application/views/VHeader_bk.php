<div class="header">
	<div class="header-top">
		<div class="container" style="text-align:left">
			<div class="col-sm-4 header-left" >
				<img  src="<?php echo LAYOUT_URL; ?>images/hotline2_edited.jpg" alt="1ngon.vn" width="12%"> 096 1756 048
				<br/><img  src="<?php echo LAYOUT_URL; ?>images/zalo_edited.jpg" alt="1ngon.vn" width="12%"> 097 7014 848
			</div>
			<div class="col-sm-4 logo" >
				<a href="<?php echo SITE_URL."product/"; ?>"><img  src="<?php echo LAYOUT_URL; ?>images/1ngon.jpeg" alt="1ngon.vn" width="70%"></a>					
			</div>				
			<div class="col-sm-4 header-right">		
					<p class="log" style="width:50%"><?php if($this->session->userdata('customer_info')){?><a id="id_log_out" href="<?php echo SITE_URL.'login/logout/';?>" title="<?php $arrCustomerInfo=$this->session->userdata('customer_info'); echo $arrCustomerInfo['phone'];?>">Đăng xuất <br/><?php echo $arrCustomerInfo['phone'];?></a><?php } else {?> <a id="id_log_in" href="<?php echo SITE_URL.'login/';?>">Đăng nhập</a><?php }?></p>
					<form class="form-horizontal" id="frm_card" style="padding-left:10px"  method="post" enctype="multipart/form-data">	
					<div class="cart box_1">
						<a href="<?php echo SITE_URL.'product/checkout/';?>">
						<h3> 
							<div style="display:inline" class="total"><span id="id_price_total"><?php if($this->session->userdata('price_total_show')>0) echo $this->session->userdata('price_total_show');?></span></div>
							<img src="<?php echo LAYOUT_URL; ?>images/cart.png" alt=""/>
							<div style="display:inline" id="id_cart"><?php if ($this->session->userdata('price_total_show')) echo "Giỏ hàng"; else echo "Chưa đặt";?></div>
						</h3>
						</a>
						
					</div>
					<div class="clearfix"> </div>
					</form>
					
			</div>
			<div class="clearfix"> </div>
		</div>

	<div class="container">
		<div class="head-top">
			<!-- <div class="col-sm-2 number"  style="text-align: left;display:inline;padding-left:0">
				<span style="font-size:12px"><i class="glyphicon glyphicon-phone"></i>0961 756 048<br/><i class="glyphicon glyphicon-phone"></i>0961 756 048</span>
			</div> -->
		 	<div class="col-sm-9 h_menu4" style="display:inline">
				<ul class="memenu skyblue">
					  <li class=" grid"><a  href="<?php echo SITE_URL."news/detail/1"; ?>">Giới thiệu</a></li>
					  <li class=" grid"><a  href="<?php echo SITE_URL."product/"; ?>">Sản phẩm</a></li>	
				      <!-- <li><a  href="#top">Sản phẩm</a>
				      	<div class="mepanel" style="width:110%">
						<div class="row">
							<div class="col2">
								<div class="h_nav">
									<h4><a href="<?php echo SITE_URL."product/type/1/";?>">Món chính</a></h4>
									<ul><?php foreach($product_type_1 as $ls1){ ?>
										<li><a href="<?php echo SITE_URL."product/index/".$ls1->id_product_type."/"; ?>"><?php echo $ls1->product_type_name;?></a></li>										
										<?php }?>
									</ul>	
								</div>							
							</div>
							<div class="col2">
								<div class="h_nav">
									<h4><a href="<?php echo SITE_URL."product/type/2/";?>">Món phụ</a></h4>
									<ul><?php foreach($product_type_2 as $ls2){ ?>
										<li><a href="<?php echo SITE_URL."product/index/".$ls2->id_product_type."/"; ?>"><?php echo $ls2->product_type_name;?></a></li>										
										<?php }?>
									</ul>	
								</div>							
							</div>
							<div class="col2">
								<div class="h_nav">
									<h4><a href="<?php echo SITE_URL."product/type/3/";?>">Nước uống</a></h4>
									<ul>
										<?php foreach($product_type_3 as $ls3){ ?>
										<li><a href="<?php echo SITE_URL."product/index/".$ls3->id_product_type."/"; ?>"><?php echo $ls3->product_type_name;?></a></li>										
										<?php }?>										
									</ul>	
								</div>												
							</div>
						  </div>
						</div>
					</li> -->
				    <li class=" grid"><a  href="<?php echo SITE_URL."news/detail/2"; ?>">Quà tặng giới thiệu</a></li>
			    	<li class=" grid"><a  href="<?php echo SITE_URL."friends/view/"; ?>">Tra cứu quà</a></li>
			    	<li><a class="color6" href="<?php echo SITE_URL.'news/detail/3'; ?>">Giao hàng</a></li>					
			  </ul> 
			</div>				
		
		<div style="display:inline;">
		<a href="#" onclick="feedToWallHeader()"><img width="90px" src="<?php echo LAYOUT_URL; ?>images/share_1ngon.png" alt="1ngon.vn"></a>
						<script>
							  window.fbAsyncInit = function() {
							    FB.init({
								  <?php if($_SERVER['HTTP_HOST']=='1ngon.vn'){?>
							      appId      : '1154466961282709',
							      <?php }elseif($_SERVER['HTTP_HOST']=='1ngon.com'){?>
							      appId      : '276848525992952',
							      <?php }else{?>
							      appId      : '1012147018834088',
							      <?php }?>
							      xfbml      : true,
							      version    : 'v2.6'
							    });
							  };
							
							  (function(d, s, id){
							     var js, fjs = d.getElementsByTagName(s)[0];
							     if (d.getElementById(id)) {return;}
							     js = d.createElement(s); js.id = id;
							     js.src = "//connect.facebook.net/en_US/sdk.js";
							     fjs.parentNode.insertBefore(js, fjs);
							   }(document, 'script', 'facebook-jssdk'));

						      function feedToWallHeader() {
						         FB.ui({
						             method: "feed",
						             link: "<?php echo SITE_URL.'product/';?>",
						             picture: "<?php echo LAYOUT_URL.'images/GaBoXoiShare.jpg';?>",
						             name: "Gà ta bó xôi, nướng muối ớt, phô mai, BBQ, nổ/hấp muối hột,..",
						             description: "- Trọng lượng 1 con gà từ 1,3 - 1,5kg - Xôi hấp lá dứa, được thêm nước cốt dừa béo ngậy, 1 trái bắp mỹ thơm ngon và được tẩm ướp gia vị có vị ngọt hoặc mặn theo yêu cầu của khách hàng.- Bụng gà được dồn hạt sen, nấm đông cô, gan, mề của chính con gà.",
						             caption: "<?php echo $_SERVER['HTTP_HOST']?> - Món ăn ngon và tiện lợi."						             
						         }, function(response) {
						             // check feed to wall
						             if (response && response.post_id) {
						                 writeLog("<?php echo SITE_URL;?>","<?php echo $_SERVER['HTTP_HOST'];?>","share_header",1);
						             } else {
						            	 writeLog("<?php echo SITE_URL;?>","<?php echo $_SERVER['HTTP_HOST'];?>","share_header",0);
						             }
						         });
						     };
						    
						</script>
		</div>		
		</div>
		
	</div>
</div>