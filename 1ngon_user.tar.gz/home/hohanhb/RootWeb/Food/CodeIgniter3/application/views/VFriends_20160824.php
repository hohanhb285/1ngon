<div class="container">
	<div class="check-out">
		<table id="CheckOutTable">
		  <tr>
		  	<th colspan="5"  style="text-align:center">Thông tin mua và tặng</th>
		  </tr>
		  <tr style="text-align:center">
		  	<th>SL đã mua(A)</th>		  	
			<th>Được tặng</th>		
			<th>Đã tặng(B)</th>
			<th>Chưa nhận(C)</th>
			<th>Còn tích lũy</th>				
		  </tr>
		  <tr style="text-align:center">
			<td><div id="id_quantity_total"></div></td>			
			<td><div id="id_quantity_total5"></div></td>		
			<td><div id="id_quantity_total2"></div></td>
			<td><div id="id_quantity_total3"></div></td>
			<td><div id="id_quantity_total4"></div></td>
		  </tr>
		</table>  
		
		<table id="CheckOutTable">
		  <tr>
		  	<th colspan="5">A. Danh sách đã mua</th>
		  </tr>
		  <tr>
		  	<th>STT</th>		  	
			<th>Số ĐT</th>		
			<th>Họ tên</th>
			<th>Đã mua</th>
			<th>Chi tiết</th>				
		  </tr>
		  <?php 
		  	$gift_config=GIFT_QUANTITY;
		   	$num=0;
		  	$quantity_total=0;
		  	foreach($friends as $list){ 
			$num++;
			$quantity_total+=$list->quantity_total;?>
		  <tr>
			<td><?php echo $num;?></td>			
			<td><?php echo $list->phone;?></td>		
			<td><?php echo $list->fullname;?></td>
			<td><?php echo $list->quantity_total;?></td>
			<td><!-- <a href="<?php echo SITE_URL."friends/order/".$list->id_customer;?>" class=" to-buy">Chi tiết</a> --></td>
		  </tr>		  
		  <?php }?>
		  <tr>
			<td colspan="3" style="text-align:right"><strong>1. Tổng SL mua </strong></td>			
			<td> <?php echo $quantity_total;?></td>		
			<td><a href="<?php echo SITE_URL."friends/order/";?>" class=" to-buy">Chi tiết</a></td>
		  </tr>
		  <tr>
		  	<th colspan="5">B. Danh sách đã tặng</th>
		  </tr>
		  <tr>
		  	<th>STT</th>		  	
			<th>Sản phẩm</th>		
			<th>Giá</th>
			<th>Đã tặng</th>
			<th>Thời gian</th>				
		  </tr>	
		  <?php 
		   	$num=0;
		  	$quantity_total2=0;
		  	foreach($gift as $list2){ 
			$num++;
			$quantity_total2+=$list2->quantity;?>
		  <tr>
			<td><?php echo $num;?></td>			
			<td><?php echo $list2->product_name;?></td>
			<td><?php echo number_format($list2->price);?></td>		
			<td><?php echo $list2->quantity;?></td>			
			<td></td>
		  </tr>		  
		  <?php }?>
		  <tr>
			<td colspan="3" style="text-align:right"><strong>2. Tổng SL đã tặng </strong></td>			
			<td> <?php echo $quantity_total2;?></td>		
			<td><a href="<?php echo SITE_URL."friends/gift/";?>" class=" to-buy">Chi tiết</a></td>
		  </tr>
		  <tr>
		  	<th colspan="5">C. Danh sách bạn chưa nhận</th>
		  </tr>
		  <tr>
		  	<th>STT</th>		  	
			<th>Sản phẩm</th>		
			<th>Giá</th>
			<th>Chưa nhận</th>
			<th>Thời gian</th>				
		  </tr>	
		  <?php 
		  	$quantity_total3=floor($quantity_total/$gift_config)-$quantity_total2;
		  	if($quantity_total3<0) $quantity_total3=0;
		  		
		  	$quantity_total4=$quantity_total-(($quantity_total2+$quantity_total3)*$gift_config);
		  	$quantity_total5=floor($quantity_total/$gift_config);
		  ?>
		  <tr>
			<td colspan="3" style="text-align:right"><strong>3. Tổng SL chưa tặng </strong></td>			
			<td> <?php echo $quantity_total3;?></td>		
			<td><a href="<?php echo SITE_URL."friends/gift/";?>" class=" to-buy">Chi tiết</a></td>
		  </tr>		  
		</table>
	
	<div class="clearfix"> </div>
	
	</div>
</div>
<script>
document.getElementById("id_quantity_total").innerHTML=<?php echo $quantity_total;?>;
document.getElementById("id_quantity_total5").innerHTML=<?php echo $quantity_total5;?>;
document.getElementById("id_quantity_total2").innerHTML=<?php echo $quantity_total2;?>;
document.getElementById("id_quantity_total3").innerHTML=<?php echo $quantity_total3;?>;
document.getElementById("id_quantity_total4").innerHTML=<?php echo $quantity_total4;?>;
</script>
