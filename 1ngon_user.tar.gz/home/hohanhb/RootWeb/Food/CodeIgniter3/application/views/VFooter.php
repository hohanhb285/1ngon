	<!-- <div class="container">
		<div class="footer-top">
			<div class="col-md-8 top-footer">
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d83998.91163207516!2d2.3470599!3d48.85885894999999!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x47e66e1f06e2b70f%3A0x40b82c3688c9460!2sParis%2C+France!5e0!3m2!1sen!2sin!4v1436340519910" allowfullscreen=""></iframe>
			</div>
			<div class="col-md-4 top-footer1">
				<h2>Newsletter</h2>
					<form>
						<input type="text" value="" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='';}">
						<input type="submit" value="SUBSCRIBE">
					</form>
			</div>
			<div class="clearfix"> </div>	
		</div>	
	</div> -->
	<div class="footer-bottom">
		<div class="container">
				<div class="col-sm-3 footer-bottom-cate">
					<h6>Ngon và Tiện lợi</h6>
					<ul>
						<li><a href="#">Tiệc văn phòng</a></li>
						<li><a href="#">Tiệc gia đình</a></li>
						<li><a href="#">Hội nhóm</a></li>
						<li><a href="#">Làm quà dự tiệc</a></li>						
					</ul>
				</div>
				<div class="col-sm-3 footer-bottom-cate">
					<h6>Món chính</h6>
					<ul>
						<?php foreach($product_type_1 as $ls1){ ?>
						<li><a href="<?php echo SITE_URL."product/index/".$ls1->id_product_type."/"; ?>"><?php echo $ls1->product_type_name;?></a></li>
						<?php }?>
						
					</ul>
				</div>
				<div class="col-sm-3 footer-bottom-cate">
					<h6>Địa chỉ</h6>
					<ul>
						<li><a href="#">1Ngon</a></li>
						<li><a href="#">62/6 Trung Lân, Bà Điểm, Hóc Môn, HCM</a></li>												
					</ul>
				</div>
				
				<div class="col-sm-3 footer-bottom-cate">
					<h6>Liên hệ</h6>
					<ul>
						<li class="phone"><a href="#"><strong>Hotline</strong>: 0961 756 048</a></li>
						<li class="phone"><a href="#"><strong>Zalo</strong>: 0977 014 848</a></li>
						<li><a href="http://1ngon.vn"  target="_blank"><strong>Site</strong>: 1ngon.vn</a>, <a href="http://1ngon.com"  target="_blank">1ngon.com</a></li>
						<li><a href="http://facebook.com/1ngon"  target="_blank"><strong>Facebook</strong>: facebook.com/1ngon</a></li>						
					</ul>
					
				</div>
				<div class="clearfix"> </div>
				<p class="footer-class"> © 2016 1Ngon | Design by <a href="1ngon.vn" title="1ngon.vn" target="_blank">1Ngon.vn</a> </p>
			</div>
	</div>

