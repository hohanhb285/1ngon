jQuery(document).ready(function() {        
    if ($('.boxfbchat').length > 0) {	
    	$(".boxfbchat .label_close").click(function() {
            if ($(this).hasClass("open")) {
        		$(".boxfbchat").animate({
                    'bottom': -260
                }, 600);
				$(this).removeClass("open");
    		} else {
    	    	$(".boxfbchat").animate({
                    'bottom': 0
                }, 600);
                $(this).addClass("open");
            }

        }        
        )
        $(".boxfbchat").animate({
            'bottom': -260
        }, 600);
        $(this).removeClass("open");
    }    
})
