<div class="banner">
	<div class="col-sm-3 banner-mat">
		<img class="img-responsive"	src="<?php echo LAYOUT_URL; ?>images/ba1.jpg" alt="">
	</div>
	<div class="col-sm-6 matter-banner">
	 	<div class="slider">
	    	<div class="callbacks_container">
	      		<ul class="rslides" id="slider">
	        		<li>
	          			<img src="<?php echo LAYOUT_URL; ?>images/1.jpg" alt="">
	       			 </li>
			 		 <li>
	          			<img src="<?php echo LAYOUT_URL; ?>images/2.jpg" alt="">   
	       			 </li>
					 <li>
	          			<img src="<?php echo LAYOUT_URL; ?>images/1.jpg" alt="">
	        		</li>	
	      		</ul>
	 	 	</div>
		</div>
	</div>
	<div class="col-sm-3 banner-mat">
		<img class="img-responsive" src="<?php echo LAYOUT_URL; ?>images/ba.jpg" alt="">
	</div>
	<div class="clearfix"> </div>
</div>