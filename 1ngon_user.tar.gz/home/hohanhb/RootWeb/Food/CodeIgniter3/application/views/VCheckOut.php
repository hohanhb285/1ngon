<div class="container">
	<div class="check-out">
		<?php if(!$product_ordered){?>
			<div style="text-align:center;color:red">Bạn chưa đặt hàng. <br> Vui lòng <a href="<?php echo SITE_URL."product/";?>"> đặt hàng</a> trước khi thanh toán.</br> Cám ơn bạn đã sử dụng dịch vụ chúng tôi.</div>	 
		   <?php }else{?>			
		<h1>Xác nhận đơn hàng</h1>
    	   
			<table id="CheckOutTable">
		  <tr>
		  	<th>Thông tin Sản phẩm</th>		  	
			<th>S.lượng</th>		
			<th>Giá</th>
			<th>Thành tiền</th>
			<th>Bỏ chọn</th>	
		  </tr>
		  <?php 
		  function get_words($sentence, $count = 10) {
			  preg_match("/(?:\w+(?:\W+|$)){0,$count}/", $sentence, $matches);
			  return $matches[0];
			}
			
		  	$num=0;
		  	$money_total=0;
		  	foreach($product_ordered as $list){ 
			$num++;?>
		  <tr>
			<td class="ring-in"><a href="<?php echo SITE_URL.'product/detail/'.$list->product_name_tv;?>" class="at-in"><img src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$list->product_image;?>&watermark=1ngon.png" class="img-responsive" alt=""></a>
			<div class="sed">
				<h5><?php echo $list->product_name;?></h5>
				<!-- <p><?php //echo get_words($list->description,30);?></p> -->
				<p><?php echo $list->product_name_detail;?></p>
				<p><?php echo $list->detail_size;?></p>
				<!-- <?php //if($list->detail_note){ ?><p><?php //echo $list->detail_note;?></p><?php //}?>-->
			</div>
			<div class="clearfix"> </div></td>			
			<td class="check"><input type="text" id="quantity[<?php echo $list->id_product_order;?>]" name="quantity[<?php echo $list->id_product_order;?>]" value="<?php echo $list->quantity;?>" onchange="editCard('<?php echo SITE_URL;?>','<?php echo $list->id_product_order;?>','<?php echo $list->id_product;?>','<?php echo $list->id_product_detail;?>','<?php echo $list->price;?>')" onfocus="this.value='';" onblur="if (this.value == '') {this.value ='';}"></td>		
			<td><div id="price[<?php echo $list->id_product_order;?>]"><?php echo number_format($list->price);?></div></td>
			<?php $money_sum=$list->quantity*$list->price; $money_total=$money_total+$money_sum;?>
			<td><div id="money[<?php echo $list->id_product_order;?>]"><?php echo number_format($money_sum);?></div></td>
			<td><img width="15px" onclick="deleteCard('<?php echo SITE_URL;?>','<?php echo $list->id_product_order;?>','<?php echo $list->id_product;?>','<?php echo $list->id_product_detail;?>','<?php echo $num;?>')" src="<?php echo LAYOUT_URL; ?>images/trashcan-128.png" alt="" title="Bỏ chọn"></td>
		  </tr>
		  <?php }?>
		  <tr>
		  <td colspan="2"></td>
		  <td><strong>Tổng tiền</strong></td>
		  <td><div id="money_total"><strong><?php echo number_format($money_total);?></strong></div></td>
		  </tr>
	</table>
	<div style="text-align:center"><a onclick="nextCard('<?php echo SITE_URL;?>')" class=" to-buy">Xác nhận</a></div>
	<div class="clearfix"> </div>
	<?php }?>
	</div>
</div>
