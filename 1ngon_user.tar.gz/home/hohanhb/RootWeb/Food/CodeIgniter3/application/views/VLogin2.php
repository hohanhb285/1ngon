<form id="frmName" method="post" accept-charset="utf-8">
	<table style="text-align:left;">
		  <tr>
			<th colspan="2" style="text-align:center"><div id="message" style="color:red">Vui lòng nhập số điện thoại.<br/>Chúng tôi sẽ liện hệ bạn.</div></th>		
		  </tr>	
		  <tr>
		  	<th style="text-align:left;width:40%">Điện thoại</th>
			<th> <input style="width:90%" type="text" name="phone" id="phone"/></th>		
		  </tr>	
		  <tr>
		  <?php 
		  	$arr_customer_add_card=$this->session->userdata('customer_add_card');
		  	//0=>$id_product,1=>$id_product_detail,2=>$price,3=>$quantity,4=>$taste,5=>$call_from)
		  	$id_product=$arr_customer_add_card[0];
		  	$id_product_detail=$arr_customer_add_card[1];
		  	$price=$arr_customer_add_card[2];
		  	$quantity=$arr_customer_add_card[3];
		  	$taste=$arr_customer_add_card[4];
		  	$call_from=$arr_customer_add_card[5];
		  	//var_dump($arr_customer_add_card);		  	
		  ?>
		  	<th colspan="2" style="text-align:center"><input type="button" onclick="submitLogin2('<?php echo SITE_URL;?>','<?php echo $id_product;?>','<?php echo $id_product_detail;?>','<?php echo $price;?>','<?php echo $quantity;?>','<?php echo $taste;?>','<?php echo $call_from;?>')" class=" to-buy" name="btn_Submit" value="Đăng nhập"/> <input type="reset" name="btn_Reset" value="Nhập lại"/></th>		
		  </tr>		  
	</table>	
</form>