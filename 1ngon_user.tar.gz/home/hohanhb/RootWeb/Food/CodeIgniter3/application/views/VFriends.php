<div class="container">
	<div class="check-out">
	<div id="id_message" style="text-align:right;padding-right:2%"><a href="<?php echo SITE_URL."friends/gift/";?>" class=" to-buy">Chi tiết</a></div>   
		<table id="CheckOutTable">
		  <tr>
		  	<th colspan="5"  style="text-align:center">Thông tin mua và tặng</th>
		  </tr>
		  <tr style="text-align:center">
		  	<th>SL đã mua</th>		  	
			<th>Được tặng</th>		
			<th>Đã tặng</th>
			<th>Chưa nhận</th>
			<th>Còn tích lũy</th>				
		  </tr>
		  <tr style="text-align:center">
			<td><div id="id_quantity_total"></div></td>			
			<td><div id="id_quantity_total5"></div></td>		
			<td><div id="id_quantity_total2"></div></td>
			<td><div id="id_quantity_total3"></div></td>
			<td><div id="id_quantity_total4"></div></td>
		  </tr>
		</table> 		 
		<?php 
		  	$gift_config=GIFT_QUANTITY;
		   	$quantity_total=0;
		  	foreach($friends as $list){ 
				$quantity_total+=$list->quantity_total;
		  	}
		  
		   	$quantity_total2=0;
		  	foreach($gift as $list2){ 
				$quantity_total2+=$list2->quantity;
			  }
		 
		  	$quantity_total3=floor($quantity_total/$gift_config)-$quantity_total2;
		  	if($quantity_total3<0) $quantity_total3=0;
		  		
		  	$quantity_total4=$quantity_total-(($quantity_total2+$quantity_total3)*$gift_config);
		  	$quantity_total5=floor($quantity_total/$gift_config);
		  ?>
	<div class="clearfix"> </div>
	</div>
</div>
<script>
document.getElementById("id_quantity_total").innerHTML=<?php echo $quantity_total;?>;
document.getElementById("id_quantity_total5").innerHTML=<?php echo $quantity_total5;?>;
document.getElementById("id_quantity_total2").innerHTML=<?php echo $quantity_total2;?>;
document.getElementById("id_quantity_total3").innerHTML=<?php echo $quantity_total3;?>;
document.getElementById("id_quantity_total4").innerHTML=<?php echo $quantity_total4;?>;
</script>
