<?php
echo anchor('category/add/','Add more');
//$this->load->library('table');

$this->table->set_heading(array('ID', 'Category Name', 'Action'));
//var_dump($category);
foreach($category as $list){
	$this->table->add_row($list->id,$list->name,anchor('category/delete/'.$list->id,'Delete',array('onClick'=>"return confirm('Are you sure?')"))." | ".anchor('category/update/'.$list->id,'Update'));
}

echo $this->table->generate(); 