<div class="container">
	<div class="check-out">
		<?php if(!$product_ordered){?>
			<div style="text-align:center;color:red">Bạn chưa đặt hàng. <br> Vui lòng <a href="<?php echo SITE_URL."product/";?>"> đặt hàng</a> trước khi thanh toán.</br> Cám ơn bạn đã sử dụng dịch vụ chúng tôi.</div>	 
		   <?php }else{?>
		<h1>Xác nhận thông tin giao hàng</h1>
		<form id="myForm" name="myForm" method="post" accept-charset="utf-8">	
    	<table >
		  <tr>
		  	<th width="30%">Thông tin Giao hàng</th>
			<th width="60%" colspan="2"><div id="message" style="color:red"></div></th>		
			<th></th>
		  </tr>
		  <?php 
		  $arr_customer_info=$this->session->userdata('customer_info');
		  $arr_ship_fee_info=$this->session->userdata('ship_fee_info');
		  ?>
		  <tr>
		  	<th>Số điện thoại</th>
			<th><input	type="text" id="phone" name="phone" value="<?php echo $arr_customer_info['phone'];?>"></th>		
			<th></th>
			<th></th>
		  </tr>
		  <tr>
		  	<th>Quận/Huyện</th>
			<th>
			<select id="district" name="district">
			<?php foreach($district as $l){ ?>
			  <option value="<?php echo $l->id_district;?>" <?php if($l->id_district==$arr_ship_fee_info['district']) echo "selected"?>><?php echo $l->district_name;?></option>
			 <?php }?> 
			</select>
			</th>		
			<th></th>
			<th></th>
		  </tr>
		  <tr>
		  	<th>Địa chỉ</th>
			<th><input	type="text" id="address" name="address" style="width:100%"  value="<?php echo $arr_customer_info['address'];?>"></th>		
			<th></th>
			<th></th>
		  </tr>
		  <tr>
		  	<th>Ghi chú thêm</th>
			<th><textarea id="note" name="note" rows="2" cols="30" style="width:100%"><?php echo $arr_customer_info['note'];?></textarea></th>		
			<th></th>
			<th></th>
		  </tr>
	</table>
	<div style="text-align:center"><a onclick="confirmCard('<?php echo SITE_URL;?>')" class=" to-buy">Xác nhận</a></div>
	</form>
	<div class="clearfix"> </div>
	
	</div>
	<?php }?>
</div>
