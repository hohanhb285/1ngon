<div class="header">
	<div class="header-top">
		<div class="container" style="text-align:left; width:80%">
			<div class="col-sm-4 header-left" style="font-size:12px">
				<img src="<?php echo LAYOUT_URL; ?>images/call247.png" alt="1ngon.vn" width="11%"> 096 1756 048				
			</div>
			
			<div class="col-sm-4 logo" style="z-index: 1">
				<a id="id_logo_a" href="<?php echo SITE_URL."product/"; ?>"><img id="id_logo_img" class="img-responsive" src="<?php echo LAYOUT_URL; ?>images/1ngon.jpeg" alt="1ngon.vn" width="70%"></a>
			</div>
			
			<div class="col-sm-4 header-right">		
					<p class="log" style="width:50%"><?php if($this->session->userdata('customer_info')){?><a id="id_log_out" href="<?php echo SITE_URL.'login/logout/';?>" title="<?php $arrCustomerInfo=$this->session->userdata('customer_info'); echo $arrCustomerInfo['phone'];?>">Đăng xuất <br/><?php echo $arrCustomerInfo['phone'];?></a><?php } else {?> <a id="id_log_in" href="<?php echo SITE_URL.'login/';?>">Đăng nhập</a><?php }?></p>
					<form class="form-horizontal" id="frm_card" style="padding-left:10px"  method="post" enctype="multipart/form-data">	
					<div class="cart box_1">
						<a href="<?php echo SITE_URL.'product/checkout/';?>">
						<h3> 
							<div style="display:inline" class="total"><span id="id_price_total"><?php if($this->session->userdata('price_total_show')>0) echo $this->session->userdata('price_total_show');?></span></div>
							<img src="<?php echo LAYOUT_URL; ?>images/cart.png" alt=""/>
							<div style="display:inline" id="id_cart"><?php if ($this->session->userdata('price_total_show')) echo "Giỏ hàng"; else echo "Chưa đặt";?></div>
						</h3>
						</a>
						
					</div>					
					<div class="fb-like" data-href="https://www.facebook.com/1NGON/" data-layout="button_count" data-action="like" data-show-faces="false" data-share="true"></div>
					<div class="clearfix"> </div>
					</form>
					
			</div>
			<div class="clearfix"> </div>
		</div>

	<div class="container">
		<div class="head-top">
			<!-- <div class="col-sm-2 number"  style="text-align: left;display:inline;padding-left:0">
				<span style="font-size:12px"><i class="glyphicon glyphicon-phone"></i>0961 756 048<br/><i class="glyphicon glyphicon-phone"></i>0961 756 048</span>
			</div> -->
		 	<div class="col-sm-11 h_menu4">
				<ul class="memenu skyblue">
					  <li class=" grid"><a  href="<?php echo SITE_URL."news/about_us/"; ?>">Giới thiệu</a></li>
					  <li class=" grid"><a  href="<?php echo SITE_URL."product/"; ?>">Sản phẩm</a></li>	
				      <!-- <li><a  href="#top">Sản phẩm</a>
				      	<div class="mepanel" style="width:110%">
						<div class="row">
							<div class="col2">
								<div class="h_nav">
									<h4><a href="<?php echo SITE_URL."product/type/1/";?>">Món chính</a></h4>
									<ul><?php foreach($product_type_1 as $ls1){ ?>
										<li><a href="<?php echo SITE_URL."product/index/".$ls1->id_product_type."/"; ?>"><?php echo $ls1->product_type_name;?></a></li>										
										<?php }?>
									</ul>	
								</div>							
							</div>
							<div class="col2">
								<div class="h_nav">
									<h4><a href="<?php echo SITE_URL."product/type/2/";?>">Món phụ</a></h4>
									<ul><?php foreach($product_type_2 as $ls2){ ?>
										<li><a href="<?php echo SITE_URL."product/index/".$ls2->id_product_type."/"; ?>"><?php echo $ls2->product_type_name;?></a></li>										
										<?php }?>
									</ul>	
								</div>							
							</div>
							<div class="col2">
								<div class="h_nav">
									<h4><a href="<?php echo SITE_URL."product/type/3/";?>">Nước uống</a></h4>
									<ul>
										<?php foreach($product_type_3 as $ls3){ ?>
										<li><a href="<?php echo SITE_URL."product/index/".$ls3->id_product_type."/"; ?>"><?php echo $ls3->product_type_name;?></a></li>										
										<?php }?>										
									</ul>	
								</div>												
							</div>
						  </div>
						</div>
					</li> -->
				    <li class=" grid"><a  href="<?php echo SITE_URL."news/invite/"; ?>">Quà tặng giới thiệu</a></li>
				    <li class=" grid"><a  href="<?php echo SITE_URL."news/promotion/"; ?>">Khuyến mãi</a></li>
			    	<li class=" grid"><a  href="<?php echo SITE_URL."friends/view/"; ?>">Tra cứu quà</a></li>
			    	<li class=" grid"><a class="color6" href="<?php echo SITE_URL.'news/ship/'; ?>">Giao hàng</a></li>					
			  </ul> 
			</div>				
		
		
				
		</div>
		
	</div>
</div>