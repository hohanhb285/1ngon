<div class="container">
	<div class="check-out">
		<div id="id_message" style="text-align:right;padding-right:2%"><a class=" to-buy" onclick="javascript:history.back();"><< Quay lại </a></div>   
		<table id="CheckOutTable">
		  <tr>
		  	<th colspan="6"  style="text-align:center">Thông tin đã mua</th>
		  </tr>
		  <tr>
		  	<th>STT</th>		  	
			<th>Điện thoại</th>
			<th>Khách hàng</th>		
			<th>Sản phẩm</th>
			<th>Giá</th>
			<th>SL</th>	
			<th>Thời gian</th>					
		  </tr>
		  <?php 
		  	$num=0;
		  	$num2=0;
		  	$quantity_total=0;
		  	$quantity_total_temp=0;
		  	$row_total_temp=0;
		  	$pre_phone="";
		  	$money=0;
		  	$arr_price='';
		  	$product_gift='';
		  	//echo "<!--<pre>";
		  	//var_dump($friends_order);
		  	//echo "<pre>-->";
		  	foreach($friends_order as $list){ 
			$num++;
			$row_total_temp++;
			$quantity_total+=$list->quantity;
			$quantity_total_temp+=$list->quantity;
			$money+=$list->quantity*$list->price;
			$money_gift=($money/$quantity_total_temp);
			$arr_price[$list->product_name]=$list->price;
			
			?>
		  <tr <?php if($num2%2){?> style="background-color:#f0f8ff"<?php }else{?>style="background-color:#ffffe6"<?php }?> <?php if($quantity_total_temp==GIFT_QUANTITY){?> rowspan="<?php echo $row_total_temp;?>"<?php }?>>
			<td><?php echo $num;?></td>			
			<td><?php echo $list->phone;?></td>
			<td><?php echo $list->fullname;?></td>		
			<td><?php echo $list->product_name;?></td>
			<td><?php echo number_format($list->price);?></td>
			<td><?php echo number_format($list->quantity);?></td>
			<td><?php echo substr($list->created_datetime,0,10);?></td>
		  </tr>
		  <?php if($quantity_total_temp>=GIFT_QUANTITY){ $product_gift=getProductNameByPrice($arr_price,$money_gift)?>
		  <tr>
		  <td><strong>Tặng</strong></td>
		  <td colspan="5"><strong><?php if($quantity_total_temp>=GIFT_QUANTITY) echo "Trung bình: ".number_format($money_gift)." => ".$product_gift;?></strong></td>
		  </tr>		  
		  <?php 
		  }
		  	$pre_phone=$list->phone;
		  	if($quantity_total_temp>=GIFT_QUANTITY){
		  		$quantity_total_temp=$quantity_total_temp-GIFT_QUANTITY;
				$row_total_temp=0;
				$num2++;
				$money=0;
				//var_dump($arr_price);
				$arr_price='';
				$product_gift='';
			}
		  }?>
		  <tr>
			<td colspan="4" style="text-align:right"><strong>Tổng SL mua </strong></td>			
			<td><?php echo $quantity_total;?></td>
		  </tr>
		</table>
		
		<table id="CheckOutTable">
		  <tr>
		  	<th colspan="5"  style="text-align:center">Thông tin đã tặng</th>
		  </tr>
		  <tr>
		  	<th>STT</th>		  	
			<th>Sản phẩm</th>
			<th>Giá</th>
			<th>Số lượng</th>	
			<th>Thời gian</th>					
		  </tr>
		  <?php 
		  	$num=0;
		  	$quantity_total=0;
		  	foreach($gift as $list){ 
			$num++;
			$quantity_total+=$list->quantity;
			
			?>
		  <tr <?php if($num%2){?> style="background-color:#f0f8ff"<?php }else{?>style="background-color:#ffffe6"<?php }?> <?php if($quantity_total_temp==GIFT_QUANTITY){?> rowspan="<?php echo $row_total_temp;?>"<?php }?>>
			<td><?php echo $num;?></td>			
			<td><?php echo $list->product_name;?></td>
			<td><?php echo number_format($list->price);?></td>
			<td><?php echo number_format($list->quantity);?></td>
			<td><?php echo substr($list->created_datetime,0,10);?></td>
		  </tr>
		  <?php }?>
		  <tr>
			<td colspan="4" style="text-align:right"><strong>Tổng SL tặng </strong></td>			
			<td><?php echo $quantity_total;?></td>
		  </tr>
		</table>
	
	<div class="clearfix"> </div>
	
	</div>
</div>
<?php 
function getProductNameByPrice($arr,$price){
	$temp=100000000;
	$key_temp='';
	$value_temp='';
	foreach($arr as $key=>$value){
		if($value==$price) return $key.", giá: ".number_format($value);
		if($price>$value){
			$temp2=$price-$value;
			if($temp2<$temp){
				$temp=$temp2;
				$key_temp=$key;	
				$value_temp=$value;		
			}
		}			
	}
	if($key_temp<>''){
		return $key_temp.", giá: ".number_format($value_temp);
	}
}
?>
