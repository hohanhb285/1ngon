<div class="single">
<div class="container">

<div class="col-md-9">
	<?php 
	if(isset($product)){
		$arr_viewed=$this->session->userdata('product_viewed_list');
		$rand=rand(3,5);
		if(is_array($arr_viewed)){
			if(!array_key_exists($product->id_product,$arr_viewed))
				$arr_viewed[$product->id_product]=array($product->id_product=>$product,'star'=>$rand);
		}else
			$arr_viewed[$product->id_product]=array($product->id_product=>$product,'star'=>$rand);
		$this->session->set_userdata('product_viewed_list',$arr_viewed);
		//$this->session->unset_userdata('product_viewed_list');
	?>
	<div class="col-md-5 grid" style="float:left;">		
		<div class="flexslider">
			  <ul class="slides">
			  	
			    <li data-thumb="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$product->product_image1;?>&watermark=1ngon.png">
			        <div class="thumb-image"> <img src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$product->product_image1;?>&watermark=1ngon.png" data-imagezoom="true" class="img-responsive"> </div>
			    </li>
			    <li data-thumb="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$product->product_image2;?>&watermark=1ngon.png">
			        <div class="thumb-image"> <img src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$product->product_image2;?>&watermark=1ngon.png" data-imagezoom="true" class="img-responsive"> </div>
			    </li>
			    <li data-thumb="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$product->product_image3;?>&watermark=1ngon.png">
			        <div class="thumb-image"> <img src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$product->product_image3;?>&watermark=1ngon.png" data-imagezoom="true" class="img-responsive"> </div>
			    </li>			
			  </ul>			  
		</div>		
	</div>	
	<div class="col-md-7 single-top-in">
						<div class="single-para simpleCart_shelfItem">
						<?php $this->session->set_userdata('lastest_view_product_name',$product->product_name);?>
							<h1><?php echo $product->product_name;?></h1>
							<div class="star-on">
								<ul>
									<?php 
									$arr_viewed=$this->session->userdata('product_viewed_list');
									//var_dump($arr_viewed);
									for($i=0;$i<$arr_viewed[$product->id_product]['star'];$i++){?>
									<li><a href="#"><i class="glyphicon glyphicon-star"></i></a></li>
									<?php }?>
								</ul>
								<!-- <div class="review">
									<a href="#"> 3 reviews </a>/
									<a href="#">  Write a review</a>
								</div> -->								
							<div class="clearfix"> </div>
							</div>
							<div class="fb-like" data-href="https://www.facebook.com/1NGON/" data-layout="standard" data-action="like" data-show-faces="false" data-share="true"></div>
							<br/><br/>
							
							<!--  Price here -->							
						 	<div class="available" style="padding-top:0px">
						 		<?php 
						 		$arr_product_ordered=$this->session->userdata('product_ordered');
						 		$arr_price_ordered=$this->session->userdata('price_ordered');
						 		$arr_quantity_ordered=$this->session->userdata('quantity_ordered');
						 		?>
								<?php //var_dump($product_detail);
								if(count($product_detail)>=1){					  
								?>
									<h4>Chọn loại:</h4>
									<table class="csstable">
									<?php 
									$is_order=false;
									foreach($product_detail as $product_detail_row){
										if($product_detail_row->standard==1){
											$id_product_standard=$product_detail_row->id_product;
											$id_product_standard_detail=$product_detail_row->id_product_detail;
										}
										
										if(isset($arr_product_ordered[$product->id_product][$product_detail_row->id_product_detail]))
											$is_order=true;
									?>										
									<tr>
									<td class="csstd"><input id="id_order_select[<?php echo $product->id_product;?>][<?php echo $product_detail_row->id_product_detail;?>]" <?php if(isset($arr_product_ordered[$product->id_product][$product_detail_row->id_product_detail])) echo "checked";?> type="checkbox" name="order_select" value="<?php echo $product_detail_row->id_product_detail;?>"></td>
									<td class="csstd">
										<label style="color:#000;"><?php echo $product_detail_row->product_name_detail;?></label>
										<br><label style="color:#000;font-size:0.75em;"><?php echo $product_detail_row->size;?></label>
										<?php if($product_detail_row->note){ ?><br><label style="color:#000;font-size:0.75em;"><?php echo $product_detail_row->note;?></label><?php }?>
									</td>
									<td class="csstd">
									<label style="color:#000;"><?php echo number_format($product_detail_row->price);?></label>
									<input type="hidden" name="order_price" value="<?php echo $product_detail_row->price?>">
									</td>
									<?php
									$quantity_ordered="";
									//var_dump($arr_product_ordered);
									//var_dump($arr_quantity_ordered);
									if(isset($arr_quantity_ordered[$product->id_product][$product_detail_row->id_product_detail]))
										$quantity_ordered=$arr_quantity_ordered[$product->id_product][$product_detail_row->id_product_detail];
									else
										$quantity_ordered=1;
									?>
									<td class="csstd"><input type="text" name="order_quantity" size="1" value="<?php echo $quantity_ordered;?>"></td>
									</tr>
									<?php }?>
									</table>
									<?php if(!$is_order){?>
									<script type="text/javascript">
										document.getElementById('id_order_select['+<?php echo $id_product_standard;?>+']'+'['+<?php echo $id_product_standard_detail;?>+']').checked = true;
									</script>
									<?php }?>
								<?php }?>
								
									<div>
									<?php if(!$product->is_taste){?>
									<h4 style="display:inline">Chọn vị:</h4>
									<select style="display:inline" id="order_taste">
										<option value="1">Vừa ăn</option>
										<option value="2">Ngọt</option>
										<option value="3">Mặn</option>
									</select>
									<?php }?>
									
									<a style="display:inline;" class="cart item_add" id="id_add_cart[<?php echo $product->id_product;?>]" onclick="addCardDetail('<?php echo SITE_URL;?>','<?php echo $product->id_product;?>')"><?php if(is_array($arr_product_ordered) && array_key_exists($product->id_product,$arr_product_ordered)) echo "Đã đặt"; else echo "Đặt mua";?></a>
						
									</div>
							</div> 
							<!--  End price here -->
							
							<p><input width="16" type="image" height="15" longdesc="undefined" src="<?php echo LAYOUT_URL.'images/detail.png';?>" /> <strong>TH&Ocirc;NG TIN CHI TIẾT:</strong></p>
							<p><?php echo $product->description;?></p><br/>
							<p>
								<input width="27" type="image" height="25" src="<?php echo LAYOUT_URL.'images/chatluong.jpeg';?>" longdesc="undefined" /><strong>CAM KẾT CHẤT LƯỢNG:</strong><br />
								- G&agrave; ta thả vườn c&oacute; nguồn gốc từ Long An. G&agrave; tơ, thịt mềm, dai, d&ugrave;ng tay x&eacute; thịt ức g&agrave; thấy c&oacute; sợi chỉ nhỏ theo sớ thịt.<br />
								- G&agrave; tươi, được kiểm dịch, nhập mới hằng ng&agrave;y.&nbsp;<br />
								- Quy tr&igrave;nh chế biến đảm bảo an to&agrave;n vệ sinh thực phẩm.
							</p>
							<!--<div class="star-on">
								<ul>
									<li><a href="#"><i class="glyphicon glyphicon-star"></i></a></li>									
								</ul>
								 <div class="review">
									<a href="#"> 3 reviews </a>/
									<a href="#">  Write a review</a>
								</div> 
							<div class="clearfix"> </div>
							</div>-->
							<!--  Price here -->							
							<!-- 	<div class="available">
									<h6>Available Options :</h6>
									<ul>										
									<li>Size:
									 <select>
										<option>Large</option>
										<option>Medium</option>
										<option>small</option>
										<option>Large</option>
										<option>small</option>
									</select></li>
									<li>
									Cost:
										<select>
											<option>U.S.Dollar</option>
											<option>Euro</option>
										</select></li>
										</ul>
								</div> -->
							  <!--  End price here -->
							
								
						</div>
				</div>
			<?php 
				}	
			?>
			<div class="clearfix"> </div>
			
			<!-- Other product -->
			<div class="content-top1">
				<?php 
					if(isset($other_product)){
						$arr_product_detail_standard=$this->session->userdata('product_detail_standard');
						
						foreach($other_product as $other_product_list){
						if(isset($arr_product_detail_standard[$other_product_list->id_product]))
							$id_product_detail=$arr_product_detail_standard[$other_product_list->id_product];
						else
							$id_product_detail="";
						if($id_product_detail){
					?>
				<div class="col-md-4 col-md3" style="padding-bottom:10px">
					<div class="col-md1 simpleCart_shelfItem">
						<a href="<?php echo $other_product_list->product_name_tv;?>">
							<img class="img-responsive" src="<?php echo LAYOUT_URL.'images_product/watermark.php?image='.$other_product_list->product_image;?>&watermark=1ngon.png" alt="" />
						</a>
						<h3 style=" padding-top:4px;line-height: 2ex;height: 7.5ex;overflow: hidden;"><a href="<?php echo $other_product_list->product_name_tv;?>"><?php echo $other_product_list->product_name;?></a></h3>
						<div class="price">
								<h5 class="item_price"><?php echo number_format($other_product_list->price);?></h5>
								<a class="cart item_add" id="id_add_cart[<?php echo $other_product_list->id_product;?>]" onclick="addCard('<?php echo SITE_URL;?>','<?php echo $other_product_list->id_product;?>','<?php echo $id_product_detail;?>','<?php echo $other_product_list->price;?>','1','1','1')" class="item_add"><?php if(is_array($arr_product_ordered) && array_key_exists($other_product_list->id_product,$arr_product_ordered)) echo "Đã đặt"; else echo "Đặt mua";?></a>
								<div class="clearfix"> </div>
						</div>
					</div>
				</div>
				<?php }}}?>	
			<div class="clearfix"> </div>
			</div>
			<!-- End other product -->
		</div>
		<!-- Product Liked ,Viewed, Tag-->
		<div class="col-md-3 product-bottom">
			<?php $this->view('VProductLiked');?>
			<?php $this->view('VProductViewed');?>
			<?php $this->view('VTag');?>			
		</div>
		<div class="clearfix"> </div>
		<!-- End product Liked ,Viewed, Tag-->
	</div>
</div>

<!-- slide -->
<script src="<?php echo LAYOUT_URL; ?>js/imagezoom.js"></script>
<!--initiate accordion-->
<script type="text/javascript">
	$(function() {
	    var menu_ul = $('.menu-drop > li > ul'),
	           menu_a  = $('.menu-drop > li > a');
	    menu_ul.hide();
	    menu_a.click(function(e) {
	        e.preventDefault();
	        if(!$(this).hasClass('active')) {
	            menu_a.removeClass('active');
	            menu_ul.filter(':visible').slideUp('normal');
	            $(this).addClass('active').next().stop(true,true).slideDown('normal');
	        } else {
	            $(this).removeClass('active');
	            $(this).next().stop(true,true).slideUp('normal');
	        }
	    });
	
	});
</script>
<!-- FlexSlider -->
<script defer src="<?php echo LAYOUT_URL; ?>js/jquery.flexslider.js"></script>
<link rel="stylesheet" href="<?php echo LAYOUT_URL; ?>css/flexslider.css" type="text/css" media="screen" />

<script>
// Can also be used with $(document).ready()
$(window).load(function() {
  $('.flexslider').flexslider({
    animation: "slide",
    controlNav: "thumbnails"
  });
});
</script>

<!---pop-up-box---->
<link href="<?php echo LAYOUT_URL; ?>css/popuo-box.css" rel="stylesheet" type="text/css" media="all"/>
<script src="<?php echo LAYOUT_URL; ?>js/jquery.magnific-popup.js" type="text/javascript"></script>
<!---//pop-up-box---->
 <script>
	$(document).ready(function() {
		$('.popup-with-zoom-anim').magnificPopup({
			type: 'inline',
			fixedContentPos: false,
			fixedBgPos: true,
			overflowY: 'auto',
			closeBtnInside: true,
			preloader: false,
			midClick: true,
			removalDelay: 300,
			mainClass: 'my-mfp-zoom-in'
		});																	
	});
</script>



