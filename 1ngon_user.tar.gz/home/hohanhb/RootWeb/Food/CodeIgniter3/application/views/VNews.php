

<!--content-->
	<div class="container">
	<!-- <div class="page"> -->
		<!-- <h1 class="typo1"><?php if($this->session->userdata('news_type')==0) echo "Giới thiệu";if($this->session->userdata('news_type')==2) echo "Thông tin";?></h1> -->
	    <!--nav-->
	      <div class="page-header">
	        <!-- <h3>Navi</h3> -->
	        <?php 
				$i=0;
				foreach($news as $list){ 
					$i++;
				if($i==1){
			?>
	        <ul class="nav nav-tabs" role="tablist">
	        <?php }?>
		        <li role="presentation" class="active"><a href="#"><strong>
		        <?php if($this->uri->segment(1)=="news"){
		        	if($this->session->userdata('news_type')==1){//About us
		        ?>
		        <img width="30px" src="<?php echo LAYOUT_URL.'images/about4.png';?>"></img>
		        <?php 
		        	}else if($this->session->userdata('news_type')==2){//Gift
		        ?>
		        <img width="22px" src="<?php echo LAYOUT_URL.'images/gift_icon.jpg';?>"></img>
		        <?php 
		        	}else if($this->session->userdata('news_type')==3){//Ship
		        ?>
		        	<img width="35px" src="<?php echo LAYOUT_URL.'images/car_icon.png';?>"></img>
		        <?php 
		        	}
		        }
		        ?>
		        <?php echo $list->title;?></strong></a></li>
		        <!-- <li role="presentation"><a href="#">Profile</a></li>
		        <li role="presentation"><a href="#">Messages</a></li> -->
		    <?php if($i==1){?>    
	      	</ul>
	      	<?php }?>
	      <!--<ul class="nav nav-pills" role="tablist">
		        <li role="presentation" class="active"><a href="#">Home</a></li>
		        <li role="presentation"><a href="#">Profile</a></li>
		        <li role="presentation"><a href="#">Messages</a></li>
	      	</ul> -->
	      	<div><br/><?php echo $list->description;?></div>
	      	<div><br/><?php echo $list->detail;?></div>
	      	<?php }?>
	      	<div style="text-align:center"><?php if($this->uri->segment(1)=="news"){
		        	if($this->session->userdata('news_type')==2){//Gift
		        ?>
		        <img src="<?php echo LAYOUT_URL.'images/gift.jpeg';?>"></img>
		        <?php }}?>
		    </div>
		    
	      </div>
        <!--//nav-->
        
       	<!-- </div> -->
	</div>
<!--//content-->

