<!DOCTYPE html>
<html>
<head>
	<title>Hello</title>
</head>
<body>

<p>Hello View.</p>
<p><?php echo $a; ?></p>
<p><?php echo $b; ?></p>



</body>
</html>
